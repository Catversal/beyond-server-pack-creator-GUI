const { Pool } = require('pg')

const pool = new Pool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME     || 'dnd_treasury',
  user:     process.env.DB_USER     || 'dndapp',
  password: process.env.DB_PASSWORD || 'changeme',
})

const SCHEMA = `
  -- Kampagnen
  CREATE TABLE IF NOT EXISTS campaigns (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW()
  );

  -- Währungssysteme (eine Kampagne hat genau ein System)
  CREATE TABLE IF NOT EXISTS currency_systems (
    id          SERIAL PRIMARY KEY,
    campaign_id INT NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    name        TEXT NOT NULL  -- z.B. "D&D Standard", "Eberron", ...
  );

  -- Einzelne Währungen eines Systems
  CREATE TABLE IF NOT EXISTS currencies (
    id                SERIAL PRIMARY KEY,
    currency_system_id INT NOT NULL REFERENCES currency_systems(id) ON DELETE CASCADE,
    name              TEXT NOT NULL,    -- z.B. "Gold"
    symbol            TEXT NOT NULL,    -- z.B. "gp"
    color             TEXT NOT NULL,    -- Hex ohne #, z.B. "C9A84C"
    rate_to_base      NUMERIC NOT NULL, -- Wie viel ist 1 dieser Währung in Basis-Einheiten?
    sort_order        INT  DEFAULT 0    -- Anzeigereihenfolge (höchste zuerst)
  );

  -- Kategorien einer Kampagne
  CREATE TABLE IF NOT EXISTS categories (
    id          SERIAL PRIMARY KEY,
    campaign_id INT  NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    type        TEXT NOT NULL CHECK (type IN ('income','expense'))
  );

  -- Transaktionen
  CREATE TABLE IF NOT EXISTS transactions (
    id          SERIAL PRIMARY KEY,
    campaign_id INT  NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    session     TEXT NOT NULL,
    description TEXT NOT NULL,
    category_id INT  REFERENCES categories(id) ON DELETE SET NULL,
    type        TEXT NOT NULL CHECK (type IN ('income','expense')),
    created_at  TIMESTAMPTZ DEFAULT NOW()
  );

  -- Beträge pro Währung pro Transaktion
  CREATE TABLE IF NOT EXISTS transaction_amounts (
    id             SERIAL PRIMARY KEY,
    transaction_id INT     NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    currency_id    INT     NOT NULL REFERENCES currencies(id)   ON DELETE CASCADE,
    amount         NUMERIC NOT NULL DEFAULT 0
  );
`

async function initDB() {
  const client = await pool.connect()
  try {
    await client.query(SCHEMA)
    console.log('✅  Datenbank-Schema bereit')
  } finally {
    client.release()
  }
}

module.exports = { pool, initDB }
