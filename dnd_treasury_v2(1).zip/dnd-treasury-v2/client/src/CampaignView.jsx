import { useState, useEffect, useRef, useMemo } from 'react'
import { api } from './api'
import { toBase, formatBase, makeChange } from './currency'
import {
  Plus, Trash2, ArrowLeft, TrendingUp, TrendingDown,
  ScrollText, ChevronDown, X, Settings, BarChart2,
  ArrowLeftRight, Upload, Image
} from 'lucide-react'

const TABS = ['transactions','charts','categories','currencies']

export default function CampaignView({ campaign, onBack }) {
  const [transactions, setTransactions] = useState([])
  const [currencies,   setCurrencies]   = useState([])
  const [wallet,       setWallet]       = useState([])
  const [categories,   setCategories]   = useState([])
  const [loading,  setLoading]  = useState(true)
  const [tab,      setTab]      = useState('transactions')
  const [showForm, setShowForm] = useState(false)
  const [showExchange, setShowExchange] = useState(false)
  const [form, setForm] = useState(null)
  const [filter, setFilter]         = useState('Alle')
  const [filterSess, setFilterSess] = useState('Alle')
  const formRef = useRef(null)

  async function load() {
    setLoading(true)
    const [txs, curs, cats, wal] = await Promise.all([
      api.getTransactions(campaign.id),
      api.getCurrencies(campaign.id),
      api.getCategories(campaign.id),
      api.getWallet(campaign.id),
    ])
    setTransactions(txs)
    setCurrencies(curs)
    setCategories(cats)
    setWallet(wal)
    setLoading(false)
  }

  useEffect(() => { load() }, [campaign.id])
  useEffect(() => { if (currencies.length > 0) resetForm() }, [currencies])

  function resetForm() {
    setForm({
      session:'', description:'', category_id:'', type:'income',
      inputMode: 'perCoin',   // 'perCoin' | 'total'
      totalAmount: '',         // Gesamtbetrag in Basis-Einheiten
      amounts: currencies.map(c => ({ currency_id:c.id, amount:'' }))
    })
  }

  function setAmt(currency_id, value) {
    setForm(f => ({ ...f, amounts: f.amounts.map(a =>
      a.currency_id===currency_id ? { ...a, amount:value } : a
    )}))
  }

  // Wechselgeld-Vorschau für Ausgaben
  const changePreview = useMemo(() => {
    if (!form || form.type !== 'expense') return null
    if (form.inputMode === 'total') {
      const cost = Number(form.totalAmount)
      if (!cost || cost <= 0) return null
      return makeChange(wallet, cost)
    } else {
      const cost = toBase(form.amounts.filter(a => Number(a.amount)>0), currencies)
      if (!cost) return null
      return makeChange(wallet, cost)
    }
  }, [form, wallet, currencies])

  async function addTransaction() {
    if (!form?.description) return
    let amounts = []

    if (form.type === 'expense') {
      // Automatisches Wechselgeld
      const cost = form.inputMode === 'total'
        ? Number(form.totalAmount)
        : toBase(form.amounts.filter(a=>Number(a.amount)>0), currencies)
      if (!cost) return
      const change = makeChange(wallet, cost)
      if (!change) return alert('Nicht genug Geld im Wallet!')
      amounts = change.amounts
      // Wechselgeld zurück → als positiver Betrag extra buchen
      if (change.changeBack.length > 0) {
        // Wechselgeld wird als Einnahme in einer separaten stillen Anpassung gespeichert
        for (const cb of change.changeBack) {
          await api.exchange(campaign.id, {
            from_currency_id: cb.currency_id,
            to_currency_id:   cb.currency_id,
            from_amount: -cb.amount  // negatives Delta = Gutschrift
          }).catch(() => {})
        }
        // Simpler: direkt als Wallet-Anpassung
        // Wir speichern Wechselgeld als exchange_adjustment
        for (const cb of change.changeBack) {
          await fetch(`/api/campaigns/${campaign.id}/exchange`, {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({
              from_currency_id: cb.currency_id,
              to_currency_id:   cb.currency_id,
              from_amount: 0
            })
          }).catch(()=>{})
        }
      }
    } else {
      amounts = form.amounts.filter(a => Number(a.amount)>0)
      if (!amounts.length) return
    }

    await api.createTransaction(campaign.id, {
      session: form.session || '—',
      description: form.description,
      category_id: form.category_id || null,
      type: form.type,
      amounts
    })
    await load()
    resetForm()
    setShowForm(false)
  }

  // Für Ausgaben: Wechselgeld-Logik direkt beim Eintragen
  async function addExpense() {
    if (!form?.description) return
    const cost = form.inputMode === 'total'
      ? Number(form.totalAmount)
      : toBase(form.amounts.filter(a=>Number(a.amount)>0), currencies)
    if (!cost) return

    const change = makeChange(wallet, cost)
    if (!change) return alert('Nicht genug Geld im Wallet!')

    // Transaktion mit den tatsächlich entnommenen Münzen
    await api.createTransaction(campaign.id, {
      session: form.session || '—',
      description: form.description,
      category_id: form.category_id || null,
      type: 'expense',
      amounts: change.amounts
    })

    // Wechselgeld zurück als stille Wallet-Anpassung (kein Logeintrag)
    if (change.changeBack.length > 0) {
      for (const cb of change.changeBack) {
        await fetch(`/api/campaigns/${campaign.id}/exchange`, {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({
            from_currency_id: cb.currency_id,
            to_currency_id:   cb.currency_id,
            from_amount: -cb.amount // Trick: negativ = Gutschrift
          })
        })
      }
    }

    await load()
    resetForm()
    setShowForm(false)
  }

  async function deleteTransaction(id) {
    await api.deleteTransaction(id)
    setTransactions(prev => prev.filter(t => t.id !== id))
    const wal = await api.getWallet(campaign.id)
    setWallet(wal)
  }

  // ── Berechnungen ──────────────────────────────────────────────────────────
  const incTxs  = transactions.filter(t => t.type==='income')
  const expTxs  = transactions.filter(t => t.type==='expense')
  const totalIn = toBase(incTxs.flatMap(t => t.amounts), currencies)
  const totalEx = toBase(expTxs.flatMap(t => t.amounts), currencies)
  const balance = wallet.reduce((s,c) => s + Number(c.balance)*Number(c.rate_to_base), 0)

  const catBreak = (txList, type) =>
    categories.filter(c=>c.type===type).map(cat => ({
      cat,
      sum:   toBase(txList.filter(t=>t.category_id===cat.id).flatMap(t=>t.amounts), currencies),
      count: txList.filter(t=>t.category_id===cat.id).length
    })).filter(x => x.count>0)

  const incBreak = catBreak(incTxs,'income')
  const expBreak = catBreak(expTxs,'expense')

  const sessionBalances = useMemo(() => {
    const sessMap = {}
    for (const t of transactions) {
      if (!sessMap[t.session]) sessMap[t.session] = { inc:0, exp:0 }
      const val = toBase(t.amounts, currencies)
      if (t.type==='income') sessMap[t.session].inc += val
      else                    sessMap[t.session].exp += val
    }
    let running = balance - (Object.values(sessMap).reduce((s,v)=>s+v.inc-v.exp,0))
    return Object.entries(sessMap).map(([sess,{inc,exp}]) => {
      running += inc-exp
      return { sess, inc, exp, balance:running }
    })
  }, [transactions, currencies, balance])

  const sessions = ['Alle', ...Array.from(new Set(transactions.map(t=>t.session)))]
  const filtered = transactions.filter(t => {
    if (filter==='Einnahme' && t.type!=='income')  return false
    if (filter==='Ausgabe'  && t.type!=='expense') return false
    if (filterSess!=='Alle' && t.session!==filterSess) return false
    return true
  }).slice().reverse()

  const incCats = categories.filter(c=>c.type==='income')
  const expCats = categories.filter(c=>c.type==='expense')

  if (loading) return <div className="splash"><div className="spin" style={{fontSize:32}}>⚔</div><p>Lade…</p></div>

  return (
    <div className="app">
      <div className="noise"/>

      <header className="hdr">
        <div className="hdr-inner">
          <div className="hdr-brand">
            <button className="btn-back" onClick={onBack}><ArrowLeft size={18}/></button>
            <div>
              <h1 className="camp-name">{campaign.name}</h1>
              <p className="hdr-sub">{campaign.cs_name}</p>
            </div>
          </div>
          <div style={{display:'flex',gap:8}}>
            <button className={`btn-new btn-ghost ${showExchange?'btn-cancel':''}`}
              onClick={() => { setShowExchange(v=>!v); setShowForm(false) }}>
              <ArrowLeftRight size={15}/> Tausch
            </button>
            <button className={`btn-new ${showForm?'btn-cancel':''}`}
              onClick={() => { setShowForm(v=>!v); setShowExchange(false) }}>
              {showForm ? <><X size={15}/> Schließen</> : <><Plus size={15}/> Transaktion</>}
            </button>
          </div>
        </div>
      </header>

      <main className="main">

        {/* WALLET */}
        <section className="wallet">
          <div className="wallet-coins">
            {wallet.map(cur => (
              <div key={cur.id} className="coin">
                {cur.image_url
                  ? <img src={cur.image_url} alt={cur.name} className="coin-img"/>
                  : <div className="coin-disc" style={{background:`radial-gradient(135deg,#${cur.color}dd,#${cur.color}55)`}}/>
                }
                <span className="coin-amt">{Number(cur.balance) % 1 === 0 ? cur.balance : Number(cur.balance).toFixed(2)}</span>
                <span className="coin-lbl">{cur.symbol}</span>
              </div>
            ))}
          </div>
          <div className="balance">
            <span className="balance-label">Kontostand</span>
            <span className={`balance-val ${balance<0?'neg':''}`}>{formatBase(balance, currencies)}</span>
          </div>
        </section>

        {/* STATS */}
        <div className="stats">
          <div className="stat stat-in">
            <TrendingUp size={18} strokeWidth={1.5}/>
            <div><span className="stat-l">Einnahmen</span><span className="stat-v">{formatBase(totalIn,currencies)}</span></div>
          </div>
          <span className="stat-sep">⚔</span>
          <div className="stat stat-ex">
            <TrendingDown size={18} strokeWidth={1.5}/>
            <div><span className="stat-l">Ausgaben</span><span className="stat-v">{formatBase(totalEx,currencies)}</span></div>
          </div>
        </div>

        {/* TAUSCH PANEL */}
        {showExchange && (
          <ExchangePanel
            currencies={currencies}
            wallet={wallet}
            campaignId={campaign.id}
            onDone={async () => { const w = await api.getWallet(campaign.id); setWallet(w); setShowExchange(false) }}
            onClose={() => setShowExchange(false)}
          />
        )}

        {/* ADD FORM */}
        {showForm && form && (
          <section className="form-wrap" ref={formRef}>
            <h2 className="form-hdr"><Plus size={16}/> Neue Transaktion</h2>
            <div className="form-grid">

              <div className="field">
                <label>Session / Bezeichnung</label>
                <input type="text" placeholder="z.B. Session 4, Kapitel 2…"
                  value={form.session} onChange={e=>setForm(f=>({...f,session:e.target.value}))}
                  list="sess-suggest"/>
                <datalist id="sess-suggest">
                  {Array.from(new Set(transactions.map(t=>t.session))).map(s=><option key={s} value={s}/>)}
                </datalist>
              </div>

              <div className="field">
                <label>Typ</label>
                <div className="toggle">
                  <button className={`tog-btn ${form.type==='income'?'tog-in':''}`}
                    onClick={()=>setForm(f=>({...f,type:'income',category_id:''}))}>Einnahme</button>
                  <button className={`tog-btn ${form.type==='expense'?'tog-ex':''}`}
                    onClick={()=>setForm(f=>({...f,type:'expense',category_id:''}))}>Ausgabe</button>
                </div>
              </div>

              <div className="field field-wide">
                <label>Kategorie</label>
                <div className="sel-wrap">
                  <select value={form.category_id} onChange={e=>setForm(f=>({...f,category_id:e.target.value}))}>
                    <option value="">— wählen —</option>
                    {(form.type==='income'?incCats:expCats).map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                  <ChevronDown size={13} className="sel-icon"/>
                </div>
              </div>

              <div className="field field-full">
                <label>Beschreibung</label>
                <input type="text" placeholder="z.B. Heiltränke × 3…"
                  value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))}/>
              </div>

              {/* Eingabemodus */}
              <div className="field field-full">
                <label>Eingabemodus</label>
                <div className="toggle">
                  <button className={`tog-btn ${form.inputMode==='perCoin'?'tog-active':''}`}
                    onClick={()=>setForm(f=>({...f,inputMode:'perCoin',totalAmount:''}))}>
                    Pro Münze
                  </button>
                  <button className={`tog-btn ${form.inputMode==='total'?'tog-active':''}`}
                    onClick={()=>setForm(f=>({...f,inputMode:'total',amounts:currencies.map(c=>({currency_id:c.id,amount:''})) }))}>
                    Gesamtbetrag
                  </button>
                </div>
              </div>

              {form.inputMode === 'total' ? (
                <div className="field field-full">
                  <label>
                    Betrag in {currencies.find(c=>c.sort_order===Math.min(...currencies.map(c=>c.sort_order)))?.symbol || 'Basis'} (kleinste Einheit)
                  </label>
                  <input type="number" min="0" placeholder="z.B. 250"
                    value={form.totalAmount} onChange={e=>setForm(f=>({...f,totalAmount:e.target.value}))}/>
                </div>
              ) : (
                currencies.map(cur => (
                  <div key={cur.id} className="field">
                    <label>
                      <span className="cdot" style={{background:`#${cur.color}`}}/>
                      {cur.name} ({cur.symbol})
                    </label>
                    <input type="number" min="0" placeholder="0"
                      value={form.amounts.find(a=>a.currency_id===cur.id)?.amount||''}
                      onChange={e=>setAmt(cur.id,e.target.value)}/>
                  </div>
                ))
              )}

              {/* Wechselgeld-Vorschau bei Ausgaben */}
              {form.type==='expense' && changePreview && (
                <div className="field field-full">
                  <div className="change-preview">
                    <div className="change-row">
                      <span className="change-label">Entnommen:</span>
                      <div className="change-coins">
                        {changePreview.amounts.map(a => {
                          const cur = currencies.find(c=>c.id===a.currency_id)
                          return <span key={a.currency_id} className="tc" style={{color:`#${cur?.color}`,background:`#${cur?.color}18`,border:`1px solid #${cur?.color}44`}}>
                            {a.amount} {cur?.symbol}
                          </span>
                        })}
                      </div>
                    </div>
                    {changePreview.changeBack.length > 0 && (
                      <div className="change-row">
                        <span className="change-label">Rückgeld:</span>
                        <div className="change-coins">
                          {changePreview.changeBack.map(a => {
                            const cur = currencies.find(c=>c.id===a.currency_id)
                            return <span key={a.currency_id} className="tc" style={{color:`#${cur?.color}`,background:`#${cur?.color}18`,border:`1px solid #${cur?.color}44`}}>
                              {a.amount} {cur?.symbol}
                            </span>
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {form.type==='expense' && changePreview===null &&
                (form.inputMode==='total' ? Number(form.totalAmount)>0 :
                  form.amounts.some(a=>Number(a.amount)>0)) && (
                <div className="field field-full">
                  <div className="change-preview change-error">⚠ Nicht genug Geld im Wallet!</div>
                </div>
              )}
            </div>

            <button className="btn-submit"
              onClick={form.type==='expense' ? addExpense : addTransaction}
              disabled={
                !form.description ||
                (form.inputMode==='total' ? !form.totalAmount : !form.amounts.some(a=>Number(a.amount)>0)) ||
                (form.type==='expense' && !changePreview)
              }>
              <Plus size={15}/> Eintragen
            </button>
          </section>
        )}

        {/* TAB BAR */}
        <div className="tab-bar">
          <button className={`tab-btn ${tab==='transactions'?'tab-active':''}`} onClick={()=>setTab('transactions')}>
            <ScrollText size={15}/> Transaktionen
          </button>
          <button className={`tab-btn ${tab==='charts'?'tab-active':''}`} onClick={()=>setTab('charts')}>
            <BarChart2 size={15}/> Grafiken
          </button>
          <button className={`tab-btn ${tab==='categories'?'tab-active':''}`} onClick={()=>setTab('categories')}>
            <Settings size={15}/> Kategorien
          </button>
          <button className={`tab-btn ${tab==='currencies'?'tab-active':''}`} onClick={()=>setTab('currencies')}>
            <Image size={15}/> Währungen
          </button>
        </div>

        {/* TRANSACTIONS TAB */}
        {tab==='transactions' && (
          <section className="log">
            <div className="log-hdr">
              <h2 className="log-title" style={{fontSize:'.85rem'}}>{filtered.length} Einträge</h2>
              <div className="log-filters">
                <div className="sel-wrap sel-sm">
                  <select value={filter} onChange={e=>setFilter(e.target.value)}>
                    {['Alle','Einnahme','Ausgabe'].map(o=><option key={o}>{o}</option>)}
                  </select>
                  <ChevronDown size={11} className="sel-icon"/>
                </div>
                <div className="sel-wrap sel-sm">
                  <select value={filterSess} onChange={e=>setFilterSess(e.target.value)}>
                    {sessions.map(s=><option key={s}>{s}</option>)}
                  </select>
                  <ChevronDown size={11} className="sel-icon"/>
                </div>
              </div>
            </div>
            {filtered.length===0
              ? <div className="empty"><p>Keine Transaktionen gefunden</p></div>
              : <div className="tx-list">
                  {filtered.map(t => (
                    <div key={t.id} className={`tx ${t.type==='income'?'tx-in':'tx-ex'}`}>
                      <div className="tx-meta">
                        <span className="tx-sess">{t.session||'—'}</span>
                        <span className={`tx-type-pill ${t.type==='income'?'pill-in':'pill-ex'}`}>
                          {t.type==='income'?'Einnahme':'Ausgabe'}
                        </span>
                        {t.category_name && <span className="tx-cat-pill">{t.category_name}</span>}
                      </div>
                      <span className="tx-desc">{t.description}</span>
                      <div className="tx-bottom">
                        <div className="tx-coins">
                          {t.amounts.map(a=>(
                            <span key={a.id} className="tc"
                              style={{color:`#${a.color}`,background:`#${a.color}18`,border:`1px solid #${a.color}44`}}>
                              {a.amount} {a.symbol}
                            </span>
                          ))}
                        </div>
                        <div className="tx-right">
                          <span className={`tx-total ${t.type==='income'?'tot-in':'tot-ex'}`}>
                            {t.type==='income'?'+':'−'}{formatBase(toBase(t.amounts,currencies),currencies)}
                          </span>
                          <button className="btn-del" onClick={()=>deleteTransaction(t.id)}><Trash2 size={13}/></button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
            }
          </section>
        )}

        {/* CHARTS TAB */}
        {tab==='charts' && (
          <div className="charts-section">
            <div className="chart-card">
              <div className="chart-title">📈 Kontostand-Entwicklung</div>
              {sessionBalances.length<2
                ? <div className="empty"><p>Mindestens 2 Sessions nötig</p></div>
                : <LineChart data={sessionBalances} currencies={currencies}/>}
            </div>
            <div className="chart-card">
              <div className="chart-title">📊 Einnahmen & Ausgaben pro Session</div>
              {sessionBalances.length===0
                ? <div className="empty"><p>Noch keine Daten</p></div>
                : <BarChartComp data={sessionBalances} currencies={currencies}/>}
            </div>
            {(incBreak.length>0||expBreak.length>0) && (
              <div className="chart-card">
                <div className="chart-title">🗂 Aufschlüsselung nach Kategorie</div>
                <div className="breakdown" style={{margin:'14px 18px'}}>
                  {incBreak.length>0 && (
                    <div className="bk-col bk-in">
                      <h3 className="bk-title">✅ Einnahmen</h3>
                      {incBreak.map(({cat,sum,count})=>(
                        <div key={cat.id} className="bk-row">
                          <span className="bk-cat">{cat.name}</span>
                          <span className="bk-cnt">{count}×</span>
                          <span className="bk-sum">{formatBase(sum,currencies)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {expBreak.length>0 && (
                    <div className="bk-col bk-ex">
                      <h3 className="bk-title">❌ Ausgaben</h3>
                      {expBreak.map(({cat,sum,count})=>(
                        <div key={cat.id} className="bk-row">
                          <span className="bk-cat">{cat.name}</span>
                          <span className="bk-cnt">{count}×</span>
                          <span className="bk-sum">{formatBase(sum,currencies)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* CATEGORIES TAB */}
        {tab==='categories' && (
          <CategoryManager categories={categories} campaignId={campaign.id}
            onUpdate={async()=>{ const c=await api.getCategories(campaign.id); setCategories(c) }}/>
        )}

        {/* CURRENCIES TAB */}
        {tab==='currencies' && (
          <CurrencyManager currencies={currencies} onUpdate={async()=>{
            const [c,w]=await Promise.all([api.getCurrencies(campaign.id),api.getWallet(campaign.id)])
            setCurrencies(c); setWallet(w)
          }}/>
        )}

      </main>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════
//  EXCHANGE PANEL
// ══════════════════════════════════════════════════════════════════════════
function ExchangePanel({ currencies, wallet, campaignId, onDone, onClose }) {
  const [fromId,     setFromId]     = useState(currencies[0]?.id||'')
  const [toId,       setToId]       = useState(currencies[1]?.id||currencies[0]?.id||'')
  const [fromAmount, setFromAmount] = useState('')
  const [busy,       setBusy]       = useState(false)
  const [result,     setResult]     = useState(null)

  const fromCur = currencies.find(c=>c.id===parseInt(fromId))
  const toCur   = currencies.find(c=>c.id===parseInt(toId))
  const walFrom = wallet.find(w=>w.id===parseInt(fromId))

  const preview = useMemo(() => {
    if (!fromCur || !toCur || !fromAmount) return null
    const base    = Number(fromAmount) * Number(fromCur.rate_to_base)
    const toAmt   = base / Number(toCur.rate_to_base)
    return toAmt
  }, [fromId, toId, fromAmount, fromCur, toCur])

  async function doExchange() {
    if (!fromAmount || !preview) return
    if (Number(walFrom?.balance||0) < Number(fromAmount)) return alert('Nicht genug Münzen!')
    setBusy(true)
    try {
      const r = await api.exchange(campaignId, {
        from_currency_id: parseInt(fromId),
        to_currency_id:   parseInt(toId),
        from_amount: Number(fromAmount)
      })
      setResult(r)
      setTimeout(onDone, 1200)
    } catch(e) { alert(e.message) }
    finally { setBusy(false) }
  }

  return (
    <section className="form-wrap" style={{borderColor:'var(--border2)'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:16}}>
        <h2 className="form-hdr" style={{margin:0}}><ArrowLeftRight size={16}/> Währung tauschen</h2>
        <button className="btn-icon" onClick={onClose}><X size={16}/></button>
      </div>

      {result ? (
        <div className="change-preview" style={{textAlign:'center',padding:'16px'}}>
          ✅ {result.from_amount} {result.from_symbol} → {result.to_amount} {result.to_symbol}
        </div>
      ) : (
        <div className="form-grid">
          <div className="field">
            <label>Von</label>
            <div className="sel-wrap">
              <select value={fromId} onChange={e=>setFromId(e.target.value)}>
                {currencies.map(c=><option key={c.id} value={c.id}>{c.name} ({c.symbol}) – Bestand: {wallet.find(w=>w.id===c.id)?.balance??0}</option>)}
              </select>
              <ChevronDown size={13} className="sel-icon"/>
            </div>
          </div>

          <div className="field">
            <label>Nach</label>
            <div className="sel-wrap">
              <select value={toId} onChange={e=>setToId(e.target.value)}>
                {currencies.filter(c=>c.id!==parseInt(fromId)).map(c=><option key={c.id} value={c.id}>{c.name} ({c.symbol})</option>)}
              </select>
              <ChevronDown size={13} className="sel-icon"/>
            </div>
          </div>

          <div className="field field-full">
            <label>Menge ({fromCur?.symbol})</label>
            <input type="number" min="0" placeholder="0"
              value={fromAmount} onChange={e=>setFromAmount(e.target.value)}/>
          </div>

          {preview !== null && (
            <div className="field field-full">
              <div className="gp-preview">
                {fromAmount} {fromCur?.symbol} = <strong>{preview % 1 === 0 ? preview : preview.toFixed(4)} {toCur?.symbol}</strong>
              </div>
            </div>
          )}

          <div className="field field-full">
            <button className="btn-submit" onClick={doExchange}
              disabled={busy||!fromAmount||!preview||preview<=0}>
              <ArrowLeftRight size={15}/> Tausch durchführen
            </button>
          </div>
        </div>
      )}
    </section>
  )
}

// ══════════════════════════════════════════════════════════════════════════
//  CURRENCY MANAGER (Bildupload)
// ══════════════════════════════════════════════════════════════════════════
function CurrencyManager({ currencies, onUpdate }) {
  const [uploading, setUploading] = useState(null)
  const fileRefs = useRef({})

  async function handleUpload(cur, file) {
    if (!file) return
    setUploading(cur.id)
    try {
      await api.uploadCurrencyImg(cur.id, file)
      await onUpdate()
    } catch(e) { alert(e.message) }
    finally { setUploading(null) }
  }

  async function handleDelete(cur) {
    if (!confirm(`Bild für ${cur.name} löschen?`)) return
    await api.deleteCurrencyImg(cur.id)
    await onUpdate()
  }

  return (
    <section className="form-wrap">
      <h2 className="form-hdr"><Image size={15}/> Währungsbilder</h2>
      <p style={{fontSize:'.82rem',color:'var(--text3)',marginBottom:16}}>
        Lade ein Bild für jede Münzsorte hoch (max. 2 MB, PNG/JPG/SVG).
      </p>
      <div className="cur-img-grid">
        {currencies.map(cur => (
          <div key={cur.id} className="cur-img-card">
            {/* Vorschau */}
            <div className="cur-img-preview" style={{borderColor:`#${cur.color}44`}}>
              {cur.image_url
                ? <img src={cur.image_url} alt={cur.name}/>
                : <div className="coin-disc-lg" style={{background:`radial-gradient(135deg,#${cur.color}dd,#${cur.color}55)`}}/>
              }
            </div>
            {/* Info */}
            <div className="cur-img-info">
              <span className="cur-img-name" style={{color:`#${cur.color}`}}>{cur.name}</span>
              <span className="cur-img-symbol">{cur.symbol} · 1:{Number(cur.rate_to_base)}</span>
            </div>
            {/* Aktionen */}
            <div className="cur-img-actions">
              <input
                type="file" accept="image/*" style={{display:'none'}}
                ref={el=>fileRefs.current[cur.id]=el}
                onChange={e=>handleUpload(cur, e.target.files[0])}
              />
              <button className="btn-upload" onClick={()=>fileRefs.current[cur.id]?.click()}
                disabled={uploading===cur.id}>
                <Upload size={13}/> {uploading===cur.id ? 'Lädt…' : cur.image_url ? 'Ersetzen' : 'Hochladen'}
              </button>
              {cur.image_url && (
                <button className="btn-icon btn-icon-sm" onClick={()=>handleDelete(cur)}><Trash2 size={12}/></button>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

// ══════════════════════════════════════════════════════════════════════════
//  CATEGORY MANAGER
// ══════════════════════════════════════════════════════════════════════════
function CategoryManager({ categories, campaignId, onUpdate }) {
  const [newCat, setNewCat] = useState({ name:'', type:'income' })
  const [busy,   setBusy]   = useState(false)

  async function add() {
    if (!newCat.name.trim()) return
    setBusy(true)
    await api.createCategory(campaignId, { name:newCat.name.trim(), type:newCat.type })
    setNewCat(c=>({...c,name:''}))
    await onUpdate()
    setBusy(false)
  }

  async function del(id) { await api.deleteCategory(id); await onUpdate() }

  const incCats = categories.filter(c=>c.type==='income')
  const expCats = categories.filter(c=>c.type==='expense')

  return (
    <section className="form-wrap">
      <h2 className="form-hdr"><Settings size={15}/> Kategorien</h2>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20}}>
        {[{label:'✅ Einnahmen',list:incCats,color:'var(--green-l)'},{label:'❌ Ausgaben',list:expCats,color:'var(--red-l)'}].map(({label,list,color})=>(
          <div key={label}>
            <p style={{fontFamily:"'Cinzel',serif",fontSize:'.78rem',fontWeight:600,color,marginBottom:8}}>{label}</p>
            {list.length===0 ? <p style={{fontSize:'.8rem',color:'var(--text3)'}}>Noch keine</p>
              : list.map(cat=>(
                <div key={cat.id} className="cat-item" style={{marginBottom:4}}>
                  <span>{cat.name}</span>
                  <button className="btn-icon btn-icon-sm" onClick={()=>del(cat.id)}><Trash2 size={12}/></button>
                </div>
              ))}
          </div>
        ))}
      </div>
      <div style={{borderTop:'1px solid var(--border)',marginTop:16,paddingTop:16}}>
        <p style={{fontSize:'.72rem',letterSpacing:'.07em',textTransform:'uppercase',color:'var(--text3)',marginBottom:8}}>Neue Kategorie</p>
        <div className="add-cat-row">
          <div className="toggle" style={{flexShrink:0}}>
            <button className={`tog-btn ${newCat.type==='income'?'tog-in':''}`} onClick={()=>setNewCat(c=>({...c,type:'income'}))}>Einnahme</button>
            <button className={`tog-btn ${newCat.type==='expense'?'tog-ex':''}`} onClick={()=>setNewCat(c=>({...c,type:'expense'}))}>Ausgabe</button>
          </div>
          <input placeholder="Kategoriename…" value={newCat.name}
            onChange={e=>setNewCat(c=>({...c,name:e.target.value}))}
            onKeyDown={e=>e.key==='Enter'&&add()} style={{flex:1}}/>
          <button className="btn-new" onClick={add} disabled={busy||!newCat.name.trim()}>
            <Plus size={14}/> Hinzufügen
          </button>
        </div>
      </div>
    </section>
  )
}

// ══════════════════════════════════════════════════════════════════════════
//  CHARTS (SVG)
// ══════════════════════════════════════════════════════════════════════════
function LineChart({ data, currencies }) {
  const W=700,H=200,PAD={t:20,r:20,b:40,l:60}
  const iW=W-PAD.l-PAD.r, iH=H-PAD.t-PAD.b
  const vals=data.map(d=>d.balance), minV=Math.min(0,...vals), maxV=Math.max(0,...vals), range=maxV-minV||1
  const x=i=>PAD.l+(i/(data.length-1))*iW
  const y=v=>PAD.t+iH-((v-minV)/range)*iH
  const y0=y(0)
  const pts=data.map((d,i)=>`${x(i)},${y(d.balance)}`).join(' ')
  const area=`M${x(0)},${y0} `+data.map((d,i)=>`L${x(i)},${y(d.balance)}`).join(' ')+` L${x(data.length-1)},${y0} Z`
  const top=currencies.find(c=>c.sort_order===Math.max(...currencies.map(c=>c.sort_order)))||currencies[0]
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{width:'100%',height:'auto',display:'block',padding:'0 0 8px'}}>
      <line x1={PAD.l} y1={y0} x2={W-PAD.r} y2={y0} stroke="#3a4060" strokeWidth="1" strokeDasharray="4,3"/>
      <path d={area} fill="#C9A84C18"/>
      <polyline points={pts} fill="none" stroke="#C9A84C" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round"/>
      {data.map((d,i)=>(
        <g key={i}>
          <circle cx={x(i)} cy={y(d.balance)} r="4" fill="#C9A84C" stroke="#1A1A2E" strokeWidth="2"/>
          <text x={x(i)} y={H-8} textAnchor="middle" fontSize="10" fill="#5a6070">{d.sess}</text>
        </g>
      ))}
      {[minV,(minV+maxV)/2,maxV].map((v,i)=>(
        <text key={i} x={PAD.l-6} y={y(v)+4} textAnchor="end" fontSize="10" fill="#5a6070">
          {(v/Number(top?.rate_to_base||1)).toFixed(0)}{top?.symbol}
        </text>
      ))}
    </svg>
  )
}

function BarChartComp({ data, currencies }) {
  const W=700,H=200,PAD={t:20,r:20,b:40,l:60}
  const iW=W-PAD.l-PAD.r, iH=H-PAD.t-PAD.b
  const maxV=Math.max(...data.flatMap(d=>[d.inc,d.exp]))||1
  const bW=(iW/data.length)*0.35, gap=iW/data.length
  const top=currencies.find(c=>c.sort_order===Math.max(...currencies.map(c=>c.sort_order)))||currencies[0]
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{width:'100%',height:'auto',display:'block',padding:'0 0 8px'}}>
      <line x1={PAD.l} y1={PAD.t+iH} x2={W-PAD.r} y2={PAD.t+iH} stroke="#3a4060" strokeWidth="1"/>
      {data.map((d,i)=>{
        const cx=PAD.l+i*gap+gap/2, hIn=(d.inc/maxV)*iH, hEx=(d.exp/maxV)*iH
        return (<g key={i}>
          <rect x={cx-bW-2} y={PAD.t+iH-hIn} width={bW} height={hIn} fill="#2D6A4F" rx="2"/>
          <rect x={cx+2}    y={PAD.t+iH-hEx} width={bW} height={hEx} fill="#7B2D2D" rx="2"/>
          <text x={cx} y={H-8} textAnchor="middle" fontSize="9" fill="#5a6070">{d.sess}</text>
        </g>)
      })}
      <rect x={PAD.l} y={PAD.t} width={10} height={10} fill="#2D6A4F" rx="2"/>
      <text x={PAD.l+14} y={PAD.t+9} fontSize="10" fill="#5FBA7D">Einnahmen</text>
      <rect x={PAD.l+90} y={PAD.t} width={10} height={10} fill="#7B2D2D" rx="2"/>
      <text x={PAD.l+104} y={PAD.t+9} fontSize="10" fill="#E07070">Ausgaben</text>
      {[0,0.5,1].map((f,i)=>(
        <text key={i} x={PAD.l-6} y={PAD.t+iH-f*iH+4} textAnchor="end" fontSize="10" fill="#5a6070">
          {((f*maxV)/Number(top?.rate_to_base||1)).toFixed(0)}{top?.symbol}
        </text>
      ))}
    </svg>
  )
}
