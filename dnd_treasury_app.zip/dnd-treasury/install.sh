#!/usr/bin/env bash
# ============================================================
#  D&D Schatzkammer – Installations-Script
#  Getestet auf: Debian 12, Ubuntu 22.04/24.04
#  Führe aus als root oder mit sudo
# ============================================================
set -e

APP_DIR="/opt/dnd-treasury"
APP_USER="dndapp"
PORT="${PORT:-3000}"
SERVICE="dnd-treasury"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# ── Root-Check ─────────────────────────────────────────────
[[ $EUID -ne 0 ]] && error "Bitte als root oder mit sudo ausführen."

info "=== D&D Schatzkammer Setup ==="

# ── Node.js installieren (falls nicht vorhanden) ───────────
if ! command -v node &>/dev/null; then
  info "Node.js wird installiert..."
  apt-get update -qq
  apt-get install -y curl ca-certificates
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
else
  NODE_VER=$(node -v)
  info "Node.js bereits installiert: $NODE_VER"
fi

# ── App-Verzeichnis ─────────────────────────────────────────
info "Verzeichnis wird angelegt: $APP_DIR"
mkdir -p "$APP_DIR"

# ── Dateien kopieren ────────────────────────────────────────
# Das Script liegt neben dem dist/ Ordner und serve.cjs
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

info "App-Dateien werden kopiert..."
cp -r "$SCRIPT_DIR/dist"     "$APP_DIR/"
cp    "$SCRIPT_DIR/serve.cjs" "$APP_DIR/"
cp    "$SCRIPT_DIR/package.json" "$APP_DIR/" 2>/dev/null || true

# ── Dedizierter System-User ─────────────────────────────────
if ! id "$APP_USER" &>/dev/null; then
  info "System-User '$APP_USER' wird erstellt..."
  useradd --system --no-create-home --shell /usr/sbin/nologin "$APP_USER"
fi
chown -R "$APP_USER:$APP_USER" "$APP_DIR"

# ── systemd Service ─────────────────────────────────────────
info "systemd Service wird erstellt..."
cat > "/etc/systemd/system/${SERVICE}.service" << EOF
[Unit]
Description=D&D Schatzkammer Web App
After=network.target

[Service]
Type=simple
User=${APP_USER}
WorkingDirectory=${APP_DIR}
ExecStart=$(which node) ${APP_DIR}/serve.cjs ${PORT}
Environment=PORT=${PORT}
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${SERVICE}

# Sicherheit
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=${APP_DIR}

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE"
systemctl restart "$SERVICE"

# ── Status & Info ───────────────────────────────────────────
sleep 1
if systemctl is-active --quiet "$SERVICE"; then
  SERVER_IP=$(hostname -I | awk '{print $1}')
  echo ""
  echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}║   ✅  Installation erfolgreich!              ║${NC}"
  echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "  🌐  App erreichbar unter:"
  echo -e "      ${GREEN}http://${SERVER_IP}:${PORT}${NC}"
  echo ""
  echo -e "  📋  Nützliche Befehle:"
  echo -e "      Status:   ${YELLOW}systemctl status ${SERVICE}${NC}"
  echo -e "      Logs:     ${YELLOW}journalctl -u ${SERVICE} -f${NC}"
  echo -e "      Stoppen:  ${YELLOW}systemctl stop ${SERVICE}${NC}"
  echo -e "      Starten:  ${YELLOW}systemctl start ${SERVICE}${NC}"
  echo ""
  echo -e "  🔧  Port ändern:"
  echo -e "      ${YELLOW}nano /etc/systemd/system/${SERVICE}.service${NC}"
  echo -e "      ${YELLOW}systemctl daemon-reload && systemctl restart ${SERVICE}${NC}"
  echo ""
else
  error "Service konnte nicht gestartet werden. Logs: journalctl -u ${SERVICE} -xe"
fi
