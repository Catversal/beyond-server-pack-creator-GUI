import { useState, useEffect } from 'react'
import { api } from './api'
import { DND_PRESET, toBase, formatBase } from './currency'
import CampaignView from './CampaignView'
import NewCampaignModal from './NewCampaignModal'
import { Plus, Sword, Trash2, ChevronRight } from 'lucide-react'
import './App.css'

export default function App() {
  const [campaigns, setCampaigns] = useState([])
  const [selected,  setSelected]  = useState(null)  // campaign id
  const [showNew,   setShowNew]   = useState(false)
  const [loading,   setLoading]   = useState(true)
  const [error,     setError]     = useState(null)

  async function load() {
    try {
      const data = await api.getCampaigns()
      setCampaigns(data)
      if (data.length === 1 && !selected) setSelected(data[0].id)
    } catch(e) { setError(e.message) }
    finally    { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  async function createCampaign(data) {
    const camp = await api.createCampaign(data)
    await load()
    setSelected(camp.id)
    setShowNew(false)
  }

  async function deleteCampaign(id, e) {
    e.stopPropagation()
    if (!confirm('Kampagne und alle Transaktionen löschen?')) return
    await api.deleteCampaign(id)
    if (selected === id) setSelected(null)
    await load()
  }

  if (loading) return <div className="splash"><Sword size={36} className="spin"/><p>Verbinde mit Server…</p></div>
  if (error)   return <div className="splash error"><p>❌ {error}</p><p className="hint">Läuft der Server? DB verbunden?</p></div>

  // Wenn eine Kampagne ausgewählt ist
  if (selected) {
    const camp = campaigns.find(c => c.id === selected)
    return (
      <CampaignView
        campaign={camp}
        onBack={() => setSelected(null)}
      />
    )
  }

  // Kampagnen-Übersicht
  return (
    <div className="app">
      <div className="noise"/>
      <header className="hdr">
        <div className="hdr-inner">
          <div className="hdr-brand">
            <Sword size={26} className="brand-icon" strokeWidth={1.5}/>
            <div>
              <h1 className="camp-name">D&amp;D Schatzkammer</h1>
              <p className="hdr-sub">Kampagnen-Übersicht</p>
            </div>
          </div>
          <button className="btn-new" onClick={() => setShowNew(true)}>
            <Plus size={15}/> Neue Kampagne
          </button>
        </div>
      </header>

      <main className="main">
        {campaigns.length === 0
          ? <div className="empty-home">
              <Sword size={52} opacity={.15}/>
              <p>Noch keine Kampagne.</p>
              <button className="btn-new btn-lg" onClick={() => setShowNew(true)}>
                <Plus size={16}/> Erste Kampagne erstellen
              </button>
            </div>
          : <div className="camp-grid">
              {campaigns.map(c => (
                <div key={c.id} className="camp-card" onClick={() => setSelected(c.id)}>
                  <div className="camp-card-body">
                    <h2 className="camp-card-name">{c.name}</h2>
                    {c.description && <p className="camp-card-desc">{c.description}</p>}
                    <span className="camp-card-system">{c.cs_name || 'Eigenes System'}</span>
                  </div>
                  <div className="camp-card-actions">
                    <button className="btn-del-camp" onClick={(e) => deleteCampaign(c.id, e)}>
                      <Trash2 size={14}/>
                    </button>
                    <ChevronRight size={20} className="camp-arrow"/>
                  </div>
                </div>
              ))}
            </div>
        }
      </main>

      {showNew && (
        <NewCampaignModal
          onClose={() => setShowNew(false)}
          onCreate={createCampaign}
        />
      )}
    </div>
  )
}
