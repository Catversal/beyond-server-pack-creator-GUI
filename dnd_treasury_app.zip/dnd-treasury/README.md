# ⚔ D&D Schatzkammer

Gold-Tracker für D&D 5e – Platin, Gold, Silber, Kupfer.

## Deploy auf Netlify (einfachste Methode)

1. Gehe zu [netlify.com](https://netlify.com) → kostenlos registrieren
2. "Add new site" → "Import an existing project" → GitHub/GitLab
   **ODER**: "Deploy manually" → einfach den `dist/` Ordner hochladen (sofort online!)
3. Fertig – die App läuft unter einer kostenlosen `.netlify.app` URL

## Deploy auf Vercel

1. Gehe zu [vercel.com](https://vercel.com) → mit GitHub anmelden
2. "New Project" → Repo importieren oder ZIP hochladen
3. Framework: **Vite** – alles automatisch

## Lokale Entwicklung

```bash
npm install
npm run dev
```

## Features

- ✅ Einnahmen & Ausgaben mit pp/gp/sp/cp
- ✅ Kategorie-Auswahl (Dropdowns)
- ✅ Session-Filterung
- ✅ Automatische Kontostand-Berechnung
- ✅ Übersicht nach Kategorien
- ✅ Daten bleiben im Browser gespeichert (localStorage)
- ✅ Kampagnenname editierbar

## Daten sichern

Öffne Browser-Konsole (F12) und führe aus:
```js
copy(localStorage.getItem('dnd-treasury'))
```
Dann in eine Textdatei einfügen – fertig.
