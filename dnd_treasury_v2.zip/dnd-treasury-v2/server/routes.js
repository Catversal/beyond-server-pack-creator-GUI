const express = require('express')
const { pool } = require('./db')
const router  = express.Router()

// ── Helper ────────────────────────────────────────────────────────────────────
const ok  = (res, data)        => res.json({ ok: true, data })
const err = (res, msg, code=500) => res.status(code).json({ ok: false, error: msg })

// ════════════════════════════════════════════════════════════════════════════
//  KAMPAGNEN
// ════════════════════════════════════════════════════════════════════════════

// GET /api/campaigns
router.get('/campaigns', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT c.*,
              cs.id   AS cs_id,
              cs.name AS cs_name
       FROM campaigns c
       LEFT JOIN currency_systems cs ON cs.campaign_id = c.id
       ORDER BY c.created_at`
    )
    ok(res, rows)
  } catch(e) { err(res, e.message) }
})

// POST /api/campaigns  { name, description, currencySystem: { name, currencies:[{name,symbol,color,rate_to_base,sort_order}] } }
router.post('/campaigns', async (req, res) => {
  const { name, description, currencySystem } = req.body
  if (!name || !currencySystem) return err(res, 'name und currencySystem erforderlich', 400)

  const client = await pool.connect()
  try {
    await client.query('BEGIN')

    const { rows: [camp] } = await client.query(
      `INSERT INTO campaigns(name, description) VALUES($1,$2) RETURNING *`,
      [name, description || null]
    )

    const { rows: [cs] } = await client.query(
      `INSERT INTO currency_systems(campaign_id, name) VALUES($1,$2) RETURNING *`,
      [camp.id, currencySystem.name]
    )

    for (const c of (currencySystem.currencies || [])) {
      await client.query(
        `INSERT INTO currencies(currency_system_id,name,symbol,color,rate_to_base,sort_order)
         VALUES($1,$2,$3,$4,$5,$6)`,
        [cs.id, c.name, c.symbol, c.color, c.rate_to_base, c.sort_order ?? 0]
      )
    }

    // Standard-Kategorien für D&D
    if (currencySystem.defaultCategories) {
      for (const cat of currencySystem.defaultCategories) {
        await client.query(
          `INSERT INTO categories(campaign_id,name,type) VALUES($1,$2,$3)`,
          [camp.id, cat.name, cat.type]
        )
      }
    }

    await client.query('COMMIT')
    ok(res, camp)
  } catch(e) {
    await client.query('ROLLBACK')
    err(res, e.message)
  } finally { client.release() }
})

// DELETE /api/campaigns/:id
router.delete('/campaigns/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM campaigns WHERE id=$1', [req.params.id])
    ok(res, { deleted: true })
  } catch(e) { err(res, e.message) }
})

// ════════════════════════════════════════════════════════════════════════════
//  WÄHRUNGEN einer Kampagne
// ════════════════════════════════════════════════════════════════════════════

// GET /api/campaigns/:id/currencies
router.get('/campaigns/:id/currencies', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT cu.* FROM currencies cu
       JOIN currency_systems cs ON cs.id = cu.currency_system_id
       WHERE cs.campaign_id = $1
       ORDER BY cu.sort_order DESC`,
      [req.params.id]
    )
    ok(res, rows)
  } catch(e) { err(res, e.message) }
})

// ════════════════════════════════════════════════════════════════════════════
//  KATEGORIEN
// ════════════════════════════════════════════════════════════════════════════

// GET /api/campaigns/:id/categories
router.get('/campaigns/:id/categories', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT * FROM categories WHERE campaign_id=$1 ORDER BY type, name`,
      [req.params.id]
    )
    ok(res, rows)
  } catch(e) { err(res, e.message) }
})

// POST /api/campaigns/:id/categories  { name, type }
router.post('/campaigns/:id/categories', async (req, res) => {
  const { name, type } = req.body
  if (!name || !['income','expense'].includes(type))
    return err(res, 'name und type (income|expense) erforderlich', 400)
  try {
    const { rows: [cat] } = await pool.query(
      `INSERT INTO categories(campaign_id,name,type) VALUES($1,$2,$3) RETURNING *`,
      [req.params.id, name, type]
    )
    ok(res, cat)
  } catch(e) { err(res, e.message) }
})

// DELETE /api/categories/:id
router.delete('/categories/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM categories WHERE id=$1', [req.params.id])
    ok(res, { deleted: true })
  } catch(e) { err(res, e.message) }
})

// ════════════════════════════════════════════════════════════════════════════
//  TRANSAKTIONEN
// ════════════════════════════════════════════════════════════════════════════

// GET /api/campaigns/:id/transactions
router.get('/campaigns/:id/transactions', async (req, res) => {
  try {
    const { rows: txs } = await pool.query(
      `SELECT t.*, cat.name AS category_name, cat.type AS category_type
       FROM transactions t
       LEFT JOIN categories cat ON cat.id = t.category_id
       WHERE t.campaign_id = $1
       ORDER BY t.created_at`,
      [req.params.id]
    )

    // Beträge für alle Transaktionen in einem Query
    const txIds = txs.map(t => t.id)
    let amounts = []
    if (txIds.length > 0) {
      const { rows } = await pool.query(
        `SELECT ta.*, cu.symbol, cu.name AS currency_name, cu.color, cu.rate_to_base
         FROM transaction_amounts ta
         JOIN currencies cu ON cu.id = ta.currency_id
         WHERE ta.transaction_id = ANY($1)`,
        [txIds]
      )
      amounts = rows
    }

    // Zusammenführen
    const result = txs.map(t => ({
      ...t,
      amounts: amounts.filter(a => a.transaction_id === t.id)
    }))

    ok(res, result)
  } catch(e) { err(res, e.message) }
})

// POST /api/campaigns/:id/transactions
// { session, description, category_id, type, amounts: [{currency_id, amount}] }
router.post('/campaigns/:id/transactions', async (req, res) => {
  const { session, description, category_id, type, amounts } = req.body
  if (!session || !description || !type || !amounts?.length)
    return err(res, 'session, description, type, amounts erforderlich', 400)

  const client = await pool.connect()
  try {
    await client.query('BEGIN')

    const { rows: [tx] } = await client.query(
      `INSERT INTO transactions(campaign_id,session,description,category_id,type)
       VALUES($1,$2,$3,$4,$5) RETURNING *`,
      [req.params.id, session, description, category_id || null, type]
    )

    for (const a of amounts) {
      if (Number(a.amount) === 0) continue
      await client.query(
        `INSERT INTO transaction_amounts(transaction_id,currency_id,amount) VALUES($1,$2,$3)`,
        [tx.id, a.currency_id, a.amount]
      )
    }

    await client.query('COMMIT')

    // Vollständige Transaktion zurückgeben
    const { rows: amountRows } = await client.query(
      `SELECT ta.*, cu.symbol, cu.name AS currency_name, cu.color, cu.rate_to_base
       FROM transaction_amounts ta
       JOIN currencies cu ON cu.id = ta.currency_id
       WHERE ta.transaction_id = $1`,
      [tx.id]
    )
    ok(res, { ...tx, amounts: amountRows })
  } catch(e) {
    await client.query('ROLLBACK')
    err(res, e.message)
  } finally { client.release() }
})

// DELETE /api/transactions/:id
router.delete('/transactions/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM transactions WHERE id=$1', [req.params.id])
    ok(res, { deleted: true })
  } catch(e) { err(res, e.message) }
})

module.exports = router
