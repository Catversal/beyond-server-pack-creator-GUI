const BASE = '/api'

async function req(method, path, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  })
  const json = await res.json()
  if (!json.ok) throw new Error(json.error)
  return json.data
}

async function uploadImage(currencyId, file) {
  const fd = new FormData()
  fd.append('image', file)
  const res = await fetch(`${BASE}/currencies/${currencyId}/image`, { method:'POST', body:fd })
  const json = await res.json()
  if (!json.ok) throw new Error(json.error)
  return json.data
}

export const api = {
  getCampaigns:      ()           => req('GET',    '/campaigns'),
  createCampaign:    (data)       => req('POST',   '/campaigns', data),
  deleteCampaign:    (id)         => req('DELETE', `/campaigns/${id}`),
  getCurrencies:     (cid)        => req('GET',    `/campaigns/${cid}/currencies`),
  getWallet:         (cid)        => req('GET',    `/campaigns/${cid}/wallet`),
  uploadCurrencyImg: (id, file)   => uploadImage(id, file),
  deleteCurrencyImg: (id)         => req('DELETE', `/currencies/${id}/image`),
  exchange:          (cid, data)  => req('POST',   `/campaigns/${cid}/exchange`, data),
  getCategories:     (cid)        => req('GET',    `/campaigns/${cid}/categories`),
  createCategory:    (cid, data)  => req('POST',   `/campaigns/${cid}/categories`, data),
  deleteCategory:    (id)         => req('DELETE', `/categories/${id}`),
  getTransactions:   (cid)        => req('GET',    `/campaigns/${cid}/transactions`),
  createTransaction: (cid, data)  => req('POST',   `/campaigns/${cid}/transactions`, data),
  deleteTransaction: (id)         => req('DELETE', `/transactions/${id}`),
}
