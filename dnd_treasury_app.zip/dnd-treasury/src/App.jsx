import { useState, useEffect, useRef } from 'react'
import { Plus, Trash2, TrendingUp, TrendingDown, Coins, ScrollText, ChevronDown, X, Sword } from 'lucide-react'
import './App.css'

const INCOME_CATS  = ['Quest-Belohnung', 'Schatzfund', 'Verkauf', 'Sonstiges (Einnahme)']
const EXPENSE_CATS = ['Ausrüstung', 'Tränke', 'Unterkunft / Rast', 'Dienste / Bezahlung', 'Essen & Trinken', 'Transport', 'Sonstiges (Ausgabe)']
const SESSIONS     = Array.from({ length: 30 }, (_, i) => `Session ${i + 1}`)
const EMPTY_FORM   = { session: 'Session 1', desc: '', cat: '', type: 'Einnahme', pp: '', gp: '', sp: '', cp: '' }

function toGP({ pp = 0, gp = 0, sp = 0, cp = 0 }) {
  return (Number(pp) * 10) + Number(gp) + (Number(sp) / 10) + (Number(cp) / 100)
}
function fmt(val) {
  return val.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' gp'
}

export default function App() {
  const [transactions, setTransactions] = useState(() => {
    try { return JSON.parse(localStorage.getItem('dnd-treasury') || '[]') } catch { return [] }
  })
  const [form, setForm]               = useState(EMPTY_FORM)
  const [showForm, setShowForm]       = useState(false)
  const [filter, setFilter]           = useState('Alle')
  const [filterSession, setFilterSession] = useState('Alle')
  const [campaign, setCampaign]       = useState(() => localStorage.getItem('dnd-campaign') || 'Meine Kampagne')
  const [editCampaign, setEditCampaign] = useState(false)
  const formRef = useRef(null)

  useEffect(() => { localStorage.setItem('dnd-treasury', JSON.stringify(transactions)) }, [transactions])
  useEffect(() => { localStorage.setItem('dnd-campaign', campaign) }, [campaign])
  useEffect(() => {
    if (showForm) setTimeout(() => formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 60)
  }, [showForm])

  const income   = transactions.filter(t => t.type === 'Einnahme')
  const expenses = transactions.filter(t => t.type === 'Ausgabe')
  const sumGP    = (list) => list.reduce((acc, t) => acc + toGP(t), 0)
  const totalIn  = sumGP(income)
  const totalEx  = sumGP(expenses)
  const balance  = totalIn - totalEx

  const wallet = transactions.reduce((acc, t) => {
    const s = t.type === 'Einnahme' ? 1 : -1
    return { pp: acc.pp + s*Number(t.pp||0), gp: acc.gp + s*Number(t.gp||0), sp: acc.sp + s*Number(t.sp||0), cp: acc.cp + s*Number(t.cp||0) }
  }, { pp:0, gp:0, sp:0, cp:0 })

  const catBreak = (list, cats) => cats.map(cat => ({
    cat, sum: sumGP(list.filter(t => t.cat === cat)), count: list.filter(t => t.cat === cat).length
  })).filter(x => x.count > 0)

  const incomeBreak  = catBreak(income, INCOME_CATS)
  const expenseBreak = catBreak(expenses, EXPENSE_CATS)

  const sessions = ['Alle', ...Array.from(new Set(transactions.map(t => t.session)))]
  const filtered = transactions.filter(t => {
    if (filter !== 'Alle' && t.type !== filter) return false
    if (filterSession !== 'Alle' && t.session !== filterSession) return false
    return true
  }).slice().reverse()

  function add() {
    if (!form.desc || !form.cat) return
    if (!form.pp && !form.gp && !form.sp && !form.cp) return
    setTransactions(prev => [...prev, { ...form, id: Date.now() }])
    setForm(EMPTY_FORM)
    setShowForm(false)
  }

  const set = f => e => setForm(v => ({ ...v, [f]: e.target.value }))

  return (
    <div className="app">
      <div className="noise" />

      {/* HEADER */}
      <header className="hdr">
        <div className="hdr-inner">
          <div className="hdr-brand">
            <Sword size={26} className="brand-icon" strokeWidth={1.5} />
            <div>
              {editCampaign
                ? <input className="camp-edit" value={campaign} autoFocus
                    onChange={e => setCampaign(e.target.value)}
                    onBlur={() => setEditCampaign(false)}
                    onKeyDown={e => e.key === 'Enter' && setEditCampaign(false)} />
                : <h1 className="camp-name" onClick={() => setEditCampaign(true)}>{campaign}</h1>}
              <p className="hdr-sub">Schatzkammer &amp; Buchführung</p>
            </div>
          </div>
          <button className={`btn-new ${showForm ? 'btn-cancel' : ''}`} onClick={() => setShowForm(v => !v)}>
            {showForm ? <><X size={16}/> Schließen</> : <><Plus size={16}/> Transaktion</>}
          </button>
        </div>
      </header>

      <main className="main">

        {/* WALLET */}
        <section className="wallet">
          <div className="wallet-coins">
            {[
              { label:'Platin',  cls:'plat',   val: wallet.pp },
              { label:'Gold',    cls:'gold',   val: wallet.gp },
              { label:'Silber',  cls:'silver', val: wallet.sp },
              { label:'Kupfer',  cls:'copper', val: wallet.cp },
            ].map(({ label, cls, val }) => (
              <div key={cls} className={`coin coin-${cls}`}>
                <div className="coin-disc" />
                <span className="coin-amt">{val}</span>
                <span className="coin-lbl">{label}</span>
              </div>
            ))}
          </div>
          <div className="balance">
            <span className="balance-label">Kontostand</span>
            <span className={`balance-val ${balance < 0 ? 'neg' : ''}`}>{fmt(balance)}</span>
          </div>
        </section>

        {/* STATS */}
        <div className="stats">
          <div className="stat stat-in">
            <TrendingUp size={18} strokeWidth={1.5}/>
            <div><span className="stat-l">Einnahmen</span><span className="stat-v">{fmt(totalIn)}</span></div>
          </div>
          <span className="stat-sep">⚔</span>
          <div className="stat stat-ex">
            <TrendingDown size={18} strokeWidth={1.5}/>
            <div><span className="stat-l">Ausgaben</span><span className="stat-v">{fmt(totalEx)}</span></div>
          </div>
        </div>

        {/* BREAKDOWN */}
        {(incomeBreak.length > 0 || expenseBreak.length > 0) && (
          <section className="breakdown">
            {[
              { title: '✅ Einnahmen', rows: incomeBreak, cls: 'bk-in' },
              { title: '❌ Ausgaben',  rows: expenseBreak, cls: 'bk-ex' },
            ].map(({ title, rows, cls }) => rows.length > 0 && (
              <div key={title} className={`bk-col ${cls}`}>
                <h3 className="bk-title">{title}</h3>
                {rows.map(({ cat, sum, count }) => (
                  <div key={cat} className="bk-row">
                    <span className="bk-cat">{cat}</span>
                    <span className="bk-cnt">{count}×</span>
                    <span className="bk-sum">{fmt(sum)}</span>
                  </div>
                ))}
              </div>
            ))}
          </section>
        )}

        {/* FORM */}
        {showForm && (
          <section className="form-wrap" ref={formRef}>
            <h2 className="form-hdr"><Plus size={16}/> Neue Transaktion</h2>
            <div className="form-grid">

              <div className="field">
                <label>Session</label>
                <div className="sel-wrap">
                  <select value={form.session} onChange={set('session')}>
                    {SESSIONS.map(s => <option key={s}>{s}</option>)}
                  </select>
                  <ChevronDown size={13} className="sel-icon"/>
                </div>
              </div>

              <div className="field">
                <label>Typ</label>
                <div className="toggle">
                  <button className={`tog-btn ${form.type==='Einnahme'?'tog-in':''}`}
                    onClick={() => setForm(f=>({...f,type:'Einnahme',cat:''}))}>Einnahme</button>
                  <button className={`tog-btn ${form.type==='Ausgabe'?'tog-ex':''}`}
                    onClick={() => setForm(f=>({...f,type:'Ausgabe',cat:''}))}>Ausgabe</button>
                </div>
              </div>

              <div className="field field-wide">
                <label>Kategorie</label>
                <div className="sel-wrap">
                  <select value={form.cat} onChange={set('cat')}>
                    <option value="">— Kategorie wählen —</option>
                    {(form.type==='Einnahme' ? INCOME_CATS : EXPENSE_CATS).map(c => <option key={c}>{c}</option>)}
                  </select>
                  <ChevronDown size={13} className="sel-icon"/>
                </div>
              </div>

              <div className="field field-full">
                <label>Beschreibung</label>
                <input type="text" placeholder="z.B. Heiltränke × 3 vom Händler in Baldurs Gate…"
                  value={form.desc} onChange={set('desc')}
                  onKeyDown={e => e.key==='Enter' && add()} />
              </div>

              {[
                { f:'pp', lbl:'Platin (pp)', cls:'plat' },
                { f:'gp', lbl:'Gold (gp)',   cls:'gold' },
                { f:'sp', lbl:'Silber (sp)', cls:'silver' },
                { f:'cp', lbl:'Kupfer (cp)', cls:'copper' },
              ].map(({ f, lbl, cls }) => (
                <div key={f} className="field">
                  <label><span className={`cdot cdot-${cls}`}/>  {lbl}</label>
                  <input type="number" min="0" placeholder="0" value={form[f]} onChange={set(f)} />
                </div>
              ))}

              {(form.pp||form.gp||form.sp||form.cp) ? (
                <div className="field field-full">
                  <div className="gp-preview">= {fmt(toGP(form))}</div>
                </div>
              ) : null}
            </div>

            <button className="btn-submit" onClick={add}
              disabled={!form.desc||!form.cat||(!form.pp&&!form.gp&&!form.sp&&!form.cp)}>
              <Plus size={15}/> Eintragen
            </button>
          </section>
        )}

        {/* LOG */}
        <section className="log">
          <div className="log-hdr">
            <h2 className="log-title"><ScrollText size={17} strokeWidth={1.5}/> Transaktionen</h2>
            <div className="log-filters">
              {[
                { val: filter, onChange: setFilter, opts: ['Alle','Einnahme','Ausgabe'] },
                { val: filterSession, onChange: setFilterSession, opts: sessions },
              ].map((f, i) => (
                <div key={i} className="sel-wrap sel-sm">
                  <select value={f.val} onChange={e => f.onChange(e.target.value)}>
                    {f.opts.map(o => <option key={o}>{o}</option>)}
                  </select>
                  <ChevronDown size={11} className="sel-icon"/>
                </div>
              ))}
            </div>
          </div>

          {filtered.length === 0
            ? <div className="empty"><Coins size={36} opacity={.25}/><p>Noch keine Einträge</p></div>
            : <div className="tx-list">
                {filtered.map(t => (
                  <div key={t.id} className={`tx ${t.type==='Einnahme'?'tx-in':'tx-ex'}`}>
                    <div className="tx-meta">
                      <span className="tx-sess">{t.session}</span>
                      <span className={`tx-type-pill ${t.type==='Einnahme'?'pill-in':'pill-ex'}`}>{t.type}</span>
                      <span className={`tx-cat-pill`}>{t.cat}</span>
                    </div>
                    <span className="tx-desc">{t.desc}</span>
                    <div className="tx-bottom">
                      <div className="tx-coins">
                        {Number(t.pp)>0 && <span className="tc tc-plat">{t.pp} pp</span>}
                        {Number(t.gp)>0 && <span className="tc tc-gold">{t.gp} gp</span>}
                        {Number(t.sp)>0 && <span className="tc tc-silver">{t.sp} sp</span>}
                        {Number(t.cp)>0 && <span className="tc tc-copper">{t.cp} cp</span>}
                      </div>
                      <div className="tx-right">
                        <span className={`tx-total ${t.type==='Einnahme'?'tot-in':'tot-ex'}`}>
                          {t.type==='Einnahme'?'+':'−'}{fmt(toGP(t))}
                        </span>
                        <button className="btn-del" onClick={() => deleteTransaction(t.id)}><Trash2 size={13}/></button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
          }
        </section>
      </main>

      <footer className="footer">
        1 pp = 10 gp &nbsp;·&nbsp; 1 gp = 10 sp &nbsp;·&nbsp; 1 sp = 10 cp
      </footer>
    </div>
  )

  function deleteTransaction(id) { setTransactions(prev => prev.filter(t => t.id !== id)) }
}
