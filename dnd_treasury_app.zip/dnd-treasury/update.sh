#!/usr/bin/env bash
# ============================================================
#  D&D Schatzkammer – Update-Script
#  Neu bauen und Service neu starten
# ============================================================
set -e

APP_DIR="/opt/dnd-treasury"
SERVICE="dnd-treasury"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${YELLOW}[UPDATE]${NC} Baue neue Version..."
cd "$SCRIPT_DIR"
npm run build

echo -e "${YELLOW}[UPDATE]${NC} Kopiere dist/ nach $APP_DIR..."
cp -r dist/ "$APP_DIR/"
cp serve.cjs "$APP_DIR/"
chown -R dndapp:dndapp "$APP_DIR"

echo -e "${YELLOW}[UPDATE]${NC} Service wird neu gestartet..."
systemctl restart "$SERVICE"

sleep 1
if systemctl is-active --quiet "$SERVICE"; then
  echo -e "${GREEN}[UPDATE]${NC} ✅ Update erfolgreich!"
else
  echo -e "\033[0;31m[UPDATE]\033[0m ❌ Service nicht gestartet – journalctl -u ${SERVICE} -xe"
fi
