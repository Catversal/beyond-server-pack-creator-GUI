import { useState, useEffect, useRef, useMemo } from 'react'
import { api } from './api'
import { toBase, formatBase } from './currency'
import {
  Plus, Trash2, ArrowLeft, TrendingUp, TrendingDown,
  ScrollText, ChevronDown, X, Settings, BarChart2
} from 'lucide-react'

const TABS = ['transactions', 'charts', 'categories']

export default function CampaignView({ campaign, onBack }) {
  const [transactions, setTransactions] = useState([])
  const [currencies,   setCurrencies]   = useState([])
  const [categories,   setCategories]   = useState([])
  const [loading,  setLoading]  = useState(true)
  const [tab,      setTab]      = useState('transactions')
  const [showForm, setShowForm] = useState(false)
  const [filter,   setFilter]   = useState('Alle')
  const [filterSess, setFilterSess] = useState('Alle')
  const [form, setForm] = useState(null)
  const formRef = useRef(null)

  // ── Load data ─────────────────────────────────────────────────────────────
  async function load() {
    setLoading(true)
    const [txs, curs, cats] = await Promise.all([
      api.getTransactions(campaign.id),
      api.getCurrencies(campaign.id),
      api.getCategories(campaign.id),
    ])
    setTransactions(txs)
    setCurrencies(curs)
    setCategories(cats)
    setLoading(false)
  }

  useEffect(() => { load() }, [campaign.id])
  useEffect(() => { if (currencies.length > 0) resetForm() }, [currencies])

  function resetForm() {
    setForm({
      session:     '',
      description: '',
      category_id: '',
      type:        'income',
      amounts:     currencies.map(c => ({ currency_id: c.id, amount: '' }))
    })
  }

  function setAmt(currency_id, value) {
    setForm(f => ({ ...f, amounts: f.amounts.map(a =>
      a.currency_id === currency_id ? { ...a, amount: value } : a
    )}))
  }

  async function addTransaction() {
    if (!form?.description) return
    if (!form.amounts.some(a => Number(a.amount) > 0)) return
    await api.createTransaction(campaign.id, {
      ...form,
      category_id: form.category_id || null,
      amounts: form.amounts.filter(a => Number(a.amount) > 0)
    })
    await load()
    resetForm()
    setShowForm(false)
  }

  async function deleteTransaction(id) {
    await api.deleteTransaction(id)
    setTransactions(prev => prev.filter(t => t.id !== id))
  }

  // ── Berechnungen ──────────────────────────────────────────────────────────
  const incTxs  = transactions.filter(t => t.type === 'income')
  const expTxs  = transactions.filter(t => t.type === 'expense')
  const totalIn = toBase(incTxs.flatMap(t => t.amounts), currencies)
  const totalEx = toBase(expTxs.flatMap(t => t.amounts), currencies)
  const balance = totalIn - totalEx

  const wallet = currencies.map(cur => {
    const inc = transactions.filter(t => t.type === 'income')
      .reduce((s,t) => s + Number(t.amounts.find(a => a.currency_id===cur.id)?.amount||0), 0)
    const exp = transactions.filter(t => t.type === 'expense')
      .reduce((s,t) => s + Number(t.amounts.find(a => a.currency_id===cur.id)?.amount||0), 0)
    return { ...cur, balance: inc - exp }
  })

  const catBreak = (txList, type) =>
    categories.filter(c => c.type === type).map(cat => ({
      cat,
      sum:   toBase(txList.filter(t => t.category_id === cat.id).flatMap(t => t.amounts), currencies),
      count: txList.filter(t => t.category_id === cat.id).length
    })).filter(x => x.count > 0)

  const incBreak = catBreak(incTxs, 'income')
  const expBreak = catBreak(expTxs, 'expense')

  // Running balance per session for line chart
  const sessionBalances = useMemo(() => {
    const sessMap = {}
    for (const t of transactions) {
      if (!sessMap[t.session]) sessMap[t.session] = { inc: 0, exp: 0 }
      const val = toBase(t.amounts, currencies)
      if (t.type === 'income') sessMap[t.session].inc += val
      else                      sessMap[t.session].exp += val
    }
    let running = 0
    return Object.entries(sessMap).map(([sess, { inc, exp }]) => {
      running += inc - exp
      return { sess, inc, exp, balance: running }
    })
  }, [transactions, currencies])

  // Filter
  const sessions = ['Alle', ...Array.from(new Set(transactions.map(t => t.session)))]
  const filtered = transactions.filter(t => {
    if (filter === 'Einnahme' && t.type !== 'income')  return false
    if (filter === 'Ausgabe'  && t.type !== 'expense') return false
    if (filterSess !== 'Alle' && t.session !== filterSess) return false
    return true
  }).slice().reverse()

  const incCats = categories.filter(c => c.type === 'income')
  const expCats = categories.filter(c => c.type === 'expense')

  if (loading) return <div className="splash"><div className="spin" style={{fontSize:32}}>⚔</div><p>Lade…</p></div>

  return (
    <div className="app">
      <div className="noise"/>

      {/* HEADER */}
      <header className="hdr">
        <div className="hdr-inner">
          <div className="hdr-brand">
            <button className="btn-back" onClick={onBack}><ArrowLeft size={18}/></button>
            <div>
              <h1 className="camp-name">{campaign.name}</h1>
              <p className="hdr-sub">{campaign.cs_name}</p>
            </div>
          </div>
          <button className={`btn-new ${showForm ? 'btn-cancel' : ''}`} onClick={() => setShowForm(v => !v)}>
            {showForm ? <><X size={15}/> Schließen</> : <><Plus size={15}/> Transaktion</>}
          </button>
        </div>
      </header>

      <main className="main">

        {/* WALLET */}
        <section className="wallet">
          <div className="wallet-coins">
            {wallet.map(cur => (
              <div key={cur.id} className="coin">
                <div className="coin-disc" style={{ background:`radial-gradient(135deg, #${cur.color}dd, #${cur.color}55)` }}/>
                <span className="coin-amt">{cur.balance}</span>
                <span className="coin-lbl">{cur.symbol}</span>
              </div>
            ))}
          </div>
          <div className="balance">
            <span className="balance-label">Kontostand</span>
            <span className={`balance-val ${balance < 0 ? 'neg' : ''}`}>{formatBase(balance, currencies)}</span>
          </div>
        </section>

        {/* STATS */}
        <div className="stats">
          <div className="stat stat-in">
            <TrendingUp size={18} strokeWidth={1.5}/>
            <div><span className="stat-l">Einnahmen</span><span className="stat-v">{formatBase(totalIn, currencies)}</span></div>
          </div>
          <span className="stat-sep">⚔</span>
          <div className="stat stat-ex">
            <TrendingDown size={18} strokeWidth={1.5}/>
            <div><span className="stat-l">Ausgaben</span><span className="stat-v">{formatBase(totalEx, currencies)}</span></div>
          </div>
        </div>

        {/* ADD FORM */}
        {showForm && form && (
          <section className="form-wrap" ref={formRef}>
            <h2 className="form-hdr"><Plus size={16}/> Neue Transaktion</h2>
            <div className="form-grid">

              {/* Session – FREITEXT */}
              <div className="field">
                <label>Session / Bezeichnung</label>
                <input
                  type="text"
                  placeholder="z.B. Session 4, Kapitel 2, Neverwinter…"
                  value={form.session}
                  onChange={e => setForm(f => ({ ...f, session: e.target.value }))}
                  list="session-suggestions"
                />
                {/* Autocomplete aus bisherigen Sessions */}
                <datalist id="session-suggestions">
                  {Array.from(new Set(transactions.map(t => t.session))).map(s => (
                    <option key={s} value={s}/>
                  ))}
                </datalist>
              </div>

              {/* Typ */}
              <div className="field">
                <label>Typ</label>
                <div className="toggle">
                  <button className={`tog-btn ${form.type==='income'  ? 'tog-in' : ''}`}
                    onClick={() => setForm(f => ({ ...f, type:'income',  category_id:'' }))}>Einnahme</button>
                  <button className={`tog-btn ${form.type==='expense' ? 'tog-ex' : ''}`}
                    onClick={() => setForm(f => ({ ...f, type:'expense', category_id:'' }))}>Ausgabe</button>
                </div>
              </div>

              {/* Kategorie */}
              <div className="field field-wide">
                <label>Kategorie</label>
                <div className="sel-wrap">
                  <select value={form.category_id} onChange={e => setForm(f => ({ ...f, category_id: e.target.value }))}>
                    <option value="">— wählen —</option>
                    {(form.type==='income' ? incCats : expCats).map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                  <ChevronDown size={13} className="sel-icon"/>
                </div>
              </div>

              {/* Beschreibung */}
              <div className="field field-full">
                <label>Beschreibung</label>
                <input type="text" placeholder="z.B. Heiltränke × 3 vom Händler in Baldurs Gate…"
                  value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  onKeyDown={e => e.key === 'Enter' && addTransaction()}/>
              </div>

              {/* Münzen */}
              {currencies.map(cur => (
                <div key={cur.id} className="field">
                  <label>
                    <span className="cdot" style={{ background:`#${cur.color}` }}/>
                    {cur.name} ({cur.symbol})
                  </label>
                  <input type="number" min="0" placeholder="0"
                    value={form.amounts.find(a => a.currency_id===cur.id)?.amount || ''}
                    onChange={e => setAmt(cur.id, e.target.value)}/>
                </div>
              ))}

              {/* Vorschau */}
              {form.amounts.some(a => Number(a.amount) > 0) && (
                <div className="field field-full">
                  <div className="gp-preview">
                    = {formatBase(toBase(form.amounts.filter(a => Number(a.amount)>0), currencies), currencies)}
                  </div>
                </div>
              )}
            </div>

            <button className="btn-submit" onClick={addTransaction}
              disabled={!form.description || !form.amounts.some(a => Number(a.amount) > 0)}>
              <Plus size={15}/> Eintragen
            </button>
          </section>
        )}

        {/* TAB BAR */}
        <div className="tab-bar">
          <button className={`tab-btn ${tab==='transactions'?'tab-active':''}`} onClick={() => setTab('transactions')}>
            <ScrollText size={15}/> Transaktionen
          </button>
          <button className={`tab-btn ${tab==='charts'?'tab-active':''}`} onClick={() => setTab('charts')}>
            <BarChart2 size={15}/> Grafiken
          </button>
          <button className={`tab-btn ${tab==='categories'?'tab-active':''}`} onClick={() => setTab('categories')}>
            <Settings size={15}/> Kategorien
          </button>
        </div>

        {/* ── TAB: TRANSACTIONS ─────────────────────────────────────────── */}
        {tab === 'transactions' && (
          <section className="log">
            <div className="log-hdr">
              <h2 className="log-title" style={{fontSize:'.85rem'}}>
                {filtered.length} Einträge
              </h2>
              <div className="log-filters">
                <div className="sel-wrap sel-sm">
                  <select value={filter} onChange={e => setFilter(e.target.value)}>
                    {['Alle','Einnahme','Ausgabe'].map(o => <option key={o}>{o}</option>)}
                  </select>
                  <ChevronDown size={11} className="sel-icon"/>
                </div>
                <div className="sel-wrap sel-sm">
                  <select value={filterSess} onChange={e => setFilterSess(e.target.value)}>
                    {sessions.map(s => <option key={s}>{s}</option>)}
                  </select>
                  <ChevronDown size={11} className="sel-icon"/>
                </div>
              </div>
            </div>

            {filtered.length === 0
              ? <div className="empty"><p>Keine Transaktionen gefunden</p></div>
              : <div className="tx-list">
                  {filtered.map(t => (
                    <div key={t.id} className={`tx ${t.type==='income'?'tx-in':'tx-ex'}`}>
                      <div className="tx-meta">
                        <span className="tx-sess">{t.session || '—'}</span>
                        <span className={`tx-type-pill ${t.type==='income'?'pill-in':'pill-ex'}`}>
                          {t.type==='income'?'Einnahme':'Ausgabe'}
                        </span>
                        {t.category_name && <span className="tx-cat-pill">{t.category_name}</span>}
                      </div>
                      <span className="tx-desc">{t.description}</span>
                      <div className="tx-bottom">
                        <div className="tx-coins">
                          {t.amounts.map(a => (
                            <span key={a.id} className="tc"
                              style={{ color:`#${a.color}`, background:`#${a.color}18`, border:`1px solid #${a.color}44` }}>
                              {a.amount} {a.symbol}
                            </span>
                          ))}
                        </div>
                        <div className="tx-right">
                          <span className={`tx-total ${t.type==='income'?'tot-in':'tot-ex'}`}>
                            {t.type==='income'?'+':'−'}{formatBase(toBase(t.amounts, currencies), currencies)}
                          </span>
                          <button className="btn-del" onClick={() => deleteTransaction(t.id)}><Trash2 size={13}/></button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
            }
          </section>
        )}

        {/* ── TAB: CHARTS ───────────────────────────────────────────────── */}
        {tab === 'charts' && (
          <div className="charts-section">

            {/* Linienchart: Kontostand pro Session */}
            <div className="chart-card">
              <div className="chart-title">📈 Kontostand-Entwicklung</div>
              {sessionBalances.length < 2
                ? <div className="empty"><p>Mindestens 2 Sessions nötig</p></div>
                : <LineChart data={sessionBalances} currencies={currencies}/>
              }
            </div>

            {/* Balken: Einnahmen vs Ausgaben pro Session */}
            <div className="chart-card">
              <div className="chart-title">📊 Einnahmen & Ausgaben pro Session</div>
              {sessionBalances.length === 0
                ? <div className="empty"><p>Noch keine Daten</p></div>
                : <BarChartComp data={sessionBalances} currencies={currencies}/>
              }
            </div>

            {/* Breakdown */}
            {(incBreak.length > 0 || expBreak.length > 0) && (
              <div className="chart-card">
                <div className="chart-title">🗂 Aufschlüsselung nach Kategorie</div>
                <div className="breakdown" style={{margin:'14px 18px'}}>
                  {incBreak.length > 0 && (
                    <div className="bk-col bk-in">
                      <h3 className="bk-title">✅ Einnahmen</h3>
                      {incBreak.map(({ cat, sum, count }) => (
                        <div key={cat.id} className="bk-row">
                          <span className="bk-cat">{cat.name}</span>
                          <span className="bk-cnt">{count}×</span>
                          <span className="bk-sum">{formatBase(sum, currencies)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {expBreak.length > 0 && (
                    <div className="bk-col bk-ex">
                      <h3 className="bk-title">❌ Ausgaben</h3>
                      {expBreak.map(({ cat, sum, count }) => (
                        <div key={cat.id} className="bk-row">
                          <span className="bk-cat">{cat.name}</span>
                          <span className="bk-cnt">{count}×</span>
                          <span className="bk-sum">{formatBase(sum, currencies)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── TAB: KATEGORIEN ───────────────────────────────────────────── */}
        {tab === 'categories' && (
          <CategoryManager
            categories={categories}
            campaignId={campaign.id}
            onUpdate={async () => {
              const cats = await api.getCategories(campaign.id)
              setCategories(cats)
            }}
          />
        )}

      </main>
    </div>
  )
}

// ════════════════════════════════════════════════════════════════════════════
//  SVG LINE CHART
// ════════════════════════════════════════════════════════════════════════════
function LineChart({ data, currencies }) {
  const W = 700, H = 200, PAD = { t:20, r:20, b:40, l:60 }
  const iW = W - PAD.l - PAD.r
  const iH = H - PAD.t - PAD.b

  const vals  = data.map(d => d.balance)
  const minV  = Math.min(0, ...vals)
  const maxV  = Math.max(0, ...vals)
  const range = maxV - minV || 1

  const x = i  => PAD.l + (i / (data.length - 1)) * iW
  const y = v  => PAD.t + iH - ((v - minV) / range) * iH
  const y0     = y(0)

  const pts = data.map((d, i) => `${x(i)},${y(d.balance)}`).join(' ')
  const area = `M${x(0)},${y0} ` +
    data.map((d,i) => `L${x(i)},${y(d.balance)}`).join(' ') +
    ` L${x(data.length-1)},${y0} Z`

  const top = currencies.find(c => c.sort_order === Math.max(...currencies.map(c=>c.sort_order))) || currencies[0]

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{width:'100%',height:'auto',display:'block',padding:'0 0 8px'}}>
      {/* Zero line */}
      <line x1={PAD.l} y1={y0} x2={W-PAD.r} y2={y0} stroke="#3a4060" strokeWidth="1" strokeDasharray="4,3"/>

      {/* Area fill */}
      <path d={area} fill="#C9A84C18"/>

      {/* Line */}
      <polyline points={pts} fill="none" stroke="#C9A84C" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round"/>

      {/* Dots + labels */}
      {data.map((d, i) => (
        <g key={i}>
          <circle cx={x(i)} cy={y(d.balance)} r="4" fill="#C9A84C" stroke="#1A1A2E" strokeWidth="2"/>
          <text x={x(i)} y={H - 8} textAnchor="middle" fontSize="10" fill="#5a6070">{d.sess}</text>
        </g>
      ))}

      {/* Y axis labels */}
      {[minV, (minV+maxV)/2, maxV].map((v,i) => (
        <text key={i} x={PAD.l - 6} y={y(v)+4} textAnchor="end" fontSize="10" fill="#5a6070">
          {(v/Number(top?.rate_to_base||1)).toFixed(0)}{top?.symbol}
        </text>
      ))}
    </svg>
  )
}

// ════════════════════════════════════════════════════════════════════════════
//  SVG BAR CHART
// ════════════════════════════════════════════════════════════════════════════
function BarChartComp({ data, currencies }) {
  const W = 700, H = 200, PAD = { t:20, r:20, b:40, l:60 }
  const iW = W - PAD.l - PAD.r
  const iH = H - PAD.t - PAD.b

  const maxV  = Math.max(...data.flatMap(d => [d.inc, d.exp])) || 1
  const bW    = (iW / data.length) * 0.35
  const gap   = iW / data.length
  const top   = currencies.find(c => c.sort_order === Math.max(...currencies.map(c=>c.sort_order))) || currencies[0]

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{width:'100%',height:'auto',display:'block',padding:'0 0 8px'}}>
      {/* Baseline */}
      <line x1={PAD.l} y1={PAD.t+iH} x2={W-PAD.r} y2={PAD.t+iH} stroke="#3a4060" strokeWidth="1"/>

      {data.map((d, i) => {
        const cx  = PAD.l + i * gap + gap/2
        const hIn = (d.inc / maxV) * iH
        const hEx = (d.exp / maxV) * iH
        return (
          <g key={i}>
            {/* Income bar */}
            <rect x={cx - bW - 2} y={PAD.t + iH - hIn} width={bW} height={hIn}
              fill="#2D6A4F" rx="2"/>
            {/* Expense bar */}
            <rect x={cx + 2} y={PAD.t + iH - hEx} width={bW} height={hEx}
              fill="#7B2D2D" rx="2"/>
            {/* Session label */}
            <text x={cx} y={H - 8} textAnchor="middle" fontSize="9" fill="#5a6070">{d.sess}</text>
          </g>
        )
      })}

      {/* Legend */}
      <rect x={PAD.l} y={PAD.t} width={10} height={10} fill="#2D6A4F" rx="2"/>
      <text x={PAD.l+14} y={PAD.t+9} fontSize="10" fill="#5FBA7D">Einnahmen</text>
      <rect x={PAD.l+90} y={PAD.t} width={10} height={10} fill="#7B2D2D" rx="2"/>
      <text x={PAD.l+104} y={PAD.t+9} fontSize="10" fill="#E07070">Ausgaben</text>

      {/* Y labels */}
      {[0, 0.5, 1].map((frac,i) => (
        <text key={i} x={PAD.l-6} y={PAD.t + iH - frac*iH + 4} textAnchor="end" fontSize="10" fill="#5a6070">
          {((frac * maxV)/Number(top?.rate_to_base||1)).toFixed(0)}{top?.symbol}
        </text>
      ))}
    </svg>
  )
}

// ════════════════════════════════════════════════════════════════════════════
//  CATEGORY MANAGER
// ════════════════════════════════════════════════════════════════════════════
function CategoryManager({ categories, campaignId, onUpdate }) {
  const [newCat, setNewCat] = useState({ name:'', type:'income' })
  const [busy,   setBusy]   = useState(false)

  async function add() {
    if (!newCat.name.trim()) return
    setBusy(true)
    await api.createCategory(campaignId, { name: newCat.name.trim(), type: newCat.type })
    setNewCat(c => ({ ...c, name:'' }))
    await onUpdate()
    setBusy(false)
  }

  async function del(id) {
    await api.deleteCategory(id)
    await onUpdate()
  }

  const incCats = categories.filter(c => c.type === 'income')
  const expCats = categories.filter(c => c.type === 'expense')

  return (
    <section className="form-wrap">
      <h2 className="form-hdr"><Settings size={15}/> Kategorien</h2>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20 }}>
        {[
          { label:'✅ Einnahmen', list: incCats, color:'var(--green-l)' },
          { label:'❌ Ausgaben',  list: expCats, color:'var(--red-l)'   },
        ].map(({ label, list, color }) => (
          <div key={label}>
            <p style={{ fontFamily:"'Cinzel',serif", fontSize:'.78rem', fontWeight:600, color, marginBottom:8 }}>{label}</p>
            {list.length === 0
              ? <p style={{ fontSize:'.8rem', color:'var(--text3)', padding:'4px 0' }}>Noch keine Kategorien</p>
              : list.map(cat => (
                  <div key={cat.id} className="cat-item" style={{ marginBottom:4 }}>
                    <span>{cat.name}</span>
                    <button className="btn-icon btn-icon-sm" onClick={() => del(cat.id)}><Trash2 size={12}/></button>
                  </div>
                ))
            }
          </div>
        ))}
      </div>

      {/* Add new category */}
      <div style={{ borderTop:'1px solid var(--border)', marginTop:16, paddingTop:16 }}>
        <p style={{ fontSize:'.72rem', letterSpacing:'.07em', textTransform:'uppercase', color:'var(--text3)', marginBottom:8 }}>
          Neue Kategorie
        </p>
        <div className="add-cat-row">
          <div className="toggle" style={{ flexShrink:0 }}>
            <button className={`tog-btn ${newCat.type==='income'  ? 'tog-in' : ''}`}
              onClick={() => setNewCat(c => ({ ...c, type:'income' }))}>Einnahme</button>
            <button className={`tog-btn ${newCat.type==='expense' ? 'tog-ex' : ''}`}
              onClick={() => setNewCat(c => ({ ...c, type:'expense' }))}>Ausgabe</button>
          </div>
          <input
            placeholder="Kategoriename…"
            value={newCat.name}
            onChange={e => setNewCat(c => ({ ...c, name: e.target.value }))}
            onKeyDown={e => e.key === 'Enter' && add()}
            style={{ flex:1 }}
          />
          <button className="btn-new" onClick={add} disabled={busy || !newCat.name.trim()}>
            <Plus size={14}/> Hinzufügen
          </button>
        </div>
      </div>
    </section>
  )
}
