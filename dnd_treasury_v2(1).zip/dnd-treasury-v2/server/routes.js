const express = require('express')
const multer  = require('multer')
const path    = require('path')
const fs      = require('fs')
const { pool } = require('./db')
const router  = express.Router()

const ok  = (res, data)          => res.json({ ok: true, data })
const err = (res, msg, code=500) => res.status(code).json({ ok: false, error: msg })

// ── Multer (Bildupload) ───────────────────────────────────────────────────
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true })

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename:    (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase()
    cb(null, `currency_${req.params.id}_${Date.now()}${ext}`)
  }
})
const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) cb(null, true)
    else cb(new Error('Nur Bilder erlaubt'))
  }
})

// ════════════════════════════════════════════════════════════════════════════
//  KAMPAGNEN
// ════════════════════════════════════════════════════════════════════════════
router.get('/campaigns', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT c.*, cs.id AS cs_id, cs.name AS cs_name
       FROM campaigns c LEFT JOIN currency_systems cs ON cs.campaign_id = c.id
       ORDER BY c.created_at`
    )
    ok(res, rows)
  } catch(e) { err(res, e.message) }
})

router.post('/campaigns', async (req, res) => {
  const { name, description, currencySystem } = req.body
  if (!name || !currencySystem) return err(res, 'name und currencySystem erforderlich', 400)
  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const { rows: [camp] } = await client.query(
      `INSERT INTO campaigns(name,description) VALUES($1,$2) RETURNING *`, [name, description||null])
    const { rows: [cs] } = await client.query(
      `INSERT INTO currency_systems(campaign_id,name) VALUES($1,$2) RETURNING *`, [camp.id, currencySystem.name])
    for (const c of (currencySystem.currencies||[])) {
      await client.query(
        `INSERT INTO currencies(currency_system_id,name,symbol,color,rate_to_base,sort_order) VALUES($1,$2,$3,$4,$5,$6)`,
        [cs.id, c.name, c.symbol, c.color, c.rate_to_base, c.sort_order??0])
    }
    if (currencySystem.defaultCategories) {
      for (const cat of currencySystem.defaultCategories) {
        await client.query(`INSERT INTO categories(campaign_id,name,type) VALUES($1,$2,$3)`, [camp.id, cat.name, cat.type])
      }
    }
    await client.query('COMMIT')
    ok(res, camp)
  } catch(e) { await client.query('ROLLBACK'); err(res, e.message) }
  finally { client.release() }
})

router.delete('/campaigns/:id', async (req, res) => {
  try { await pool.query('DELETE FROM campaigns WHERE id=$1', [req.params.id]); ok(res, { deleted:true }) }
  catch(e) { err(res, e.message) }
})

// ════════════════════════════════════════════════════════════════════════════
//  WÄHRUNGEN
// ════════════════════════════════════════════════════════════════════════════
router.get('/campaigns/:id/currencies', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT cu.* FROM currencies cu
       JOIN currency_systems cs ON cs.id = cu.currency_system_id
       WHERE cs.campaign_id=$1 ORDER BY cu.sort_order DESC`, [req.params.id])
    ok(res, rows)
  } catch(e) { err(res, e.message) }
})

// POST /api/currencies/:id/image  – Bild hochladen
router.post('/currencies/:id/image', upload.single('image'), async (req, res) => {
  if (!req.file) return err(res, 'Kein Bild', 400)
  try {
    // Altes Bild löschen
    const { rows: [cur] } = await pool.query('SELECT image_url FROM currencies WHERE id=$1', [req.params.id])
    if (cur?.image_url) {
      const old = path.join(UPLOAD_DIR, path.basename(cur.image_url))
      if (fs.existsSync(old)) fs.unlinkSync(old)
    }
    const url = `/uploads/${req.file.filename}`
    await pool.query('UPDATE currencies SET image_url=$1 WHERE id=$2', [url, req.params.id])
    ok(res, { image_url: url })
  } catch(e) { err(res, e.message) }
})

// DELETE /api/currencies/:id/image
router.delete('/currencies/:id/image', async (req, res) => {
  try {
    const { rows: [cur] } = await pool.query('SELECT image_url FROM currencies WHERE id=$1', [req.params.id])
    if (cur?.image_url) {
      const file = path.join(UPLOAD_DIR, path.basename(cur.image_url))
      if (fs.existsSync(file)) fs.unlinkSync(file)
    }
    await pool.query('UPDATE currencies SET image_url=NULL WHERE id=$1', [req.params.id])
    ok(res, { deleted: true })
  } catch(e) { err(res, e.message) }
})

// ════════════════════════════════════════════════════════════════════════════
//  WALLET (aktueller Kontostand)
// ════════════════════════════════════════════════════════════════════════════
router.get('/campaigns/:id/wallet', async (req, res) => {
  try {
    const { rows: curs } = await pool.query(
      `SELECT cu.* FROM currencies cu
       JOIN currency_systems cs ON cs.id = cu.currency_system_id
       WHERE cs.campaign_id=$1 ORDER BY cu.sort_order DESC`, [req.params.id])

    const wallet = {}
    for (const c of curs) wallet[c.id] = { ...c, balance: 0 }

    // Transaktionen
    const { rows: amounts } = await pool.query(
      `SELECT ta.currency_id, ta.amount, t.type
       FROM transaction_amounts ta JOIN transactions t ON t.id=ta.transaction_id
       WHERE t.campaign_id=$1`, [req.params.id])
    for (const a of amounts) {
      if (!wallet[a.currency_id]) continue
      wallet[a.currency_id].balance += Number(a.amount) * (a.type==='income' ? 1 : -1)
    }

    // Tausch-Anpassungen
    const { rows: adjs } = await pool.query(
      `SELECT currency_id, delta FROM exchange_adjustments WHERE campaign_id=$1`, [req.params.id])
    for (const a of adjs) {
      if (wallet[a.currency_id]) wallet[a.currency_id].balance += Number(a.delta)
    }

    ok(res, Object.values(wallet))
  } catch(e) { err(res, e.message) }
})

// ════════════════════════════════════════════════════════════════════════════
//  TAUSCH (Exchange)
// ════════════════════════════════════════════════════════════════════════════
// POST /api/campaigns/:id/exchange
// Body: { from_currency_id, to_currency_id, from_amount }
// Berechnet auf Basis rate_to_base und speichert zwei Anpassungen
router.post('/campaigns/:id/exchange', async (req, res) => {
  const { from_currency_id, to_currency_id, from_amount } = req.body
  if (!from_currency_id || !to_currency_id || !from_amount)
    return err(res, 'from_currency_id, to_currency_id, from_amount erforderlich', 400)

  const client = await pool.connect()
  try {
    const { rows: curs } = await client.query(
      `SELECT * FROM currencies WHERE id=ANY($1)`, [[from_currency_id, to_currency_id]])
    const from = curs.find(c => c.id === parseInt(from_currency_id))
    const to   = curs.find(c => c.id === parseInt(to_currency_id))
    if (!from || !to) return err(res, 'Währung nicht gefunden', 404)

    // Umrechnung: from_amount * from.rate_to_base / to.rate_to_base
    const baseValue  = Number(from_amount) * Number(from.rate_to_base)
    const to_amount  = baseValue / Number(to.rate_to_base)

    await client.query('BEGIN')
    await client.query(
      `INSERT INTO exchange_adjustments(campaign_id,currency_id,delta,note) VALUES($1,$2,$3,$4)`,
      [req.params.id, from_currency_id, -Number(from_amount), `Tausch: ${from_amount} ${from.symbol} → ${to_amount} ${to.symbol}`])
    await client.query(
      `INSERT INTO exchange_adjustments(campaign_id,currency_id,delta,note) VALUES($1,$2,$3,$4)`,
      [req.params.id, to_currency_id, to_amount, `Tausch: ${from_amount} ${from.symbol} → ${to_amount} ${to.symbol}`])
    await client.query('COMMIT')

    ok(res, { from_amount: Number(from_amount), to_amount, from_symbol: from.symbol, to_symbol: to.symbol })
  } catch(e) { await client.query('ROLLBACK'); err(res, e.message) }
  finally { client.release() }
})

// ════════════════════════════════════════════════════════════════════════════
//  KATEGORIEN
// ════════════════════════════════════════════════════════════════════════════
router.get('/campaigns/:id/categories', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT * FROM categories WHERE campaign_id=$1 ORDER BY type,name`, [req.params.id])
    ok(res, rows)
  } catch(e) { err(res, e.message) }
})

router.post('/campaigns/:id/categories', async (req, res) => {
  const { name, type } = req.body
  if (!name || !['income','expense'].includes(type)) return err(res, 'name und type erforderlich', 400)
  try {
    const { rows:[cat] } = await pool.query(
      `INSERT INTO categories(campaign_id,name,type) VALUES($1,$2,$3) RETURNING *`, [req.params.id, name, type])
    ok(res, cat)
  } catch(e) { err(res, e.message) }
})

router.delete('/categories/:id', async (req, res) => {
  try { await pool.query('DELETE FROM categories WHERE id=$1', [req.params.id]); ok(res, { deleted:true }) }
  catch(e) { err(res, e.message) }
})

// ════════════════════════════════════════════════════════════════════════════
//  TRANSAKTIONEN
// ════════════════════════════════════════════════════════════════════════════
router.get('/campaigns/:id/transactions', async (req, res) => {
  try {
    const { rows: txs } = await pool.query(
      `SELECT t.*, cat.name AS category_name, cat.type AS category_type
       FROM transactions t LEFT JOIN categories cat ON cat.id=t.category_id
       WHERE t.campaign_id=$1 ORDER BY t.created_at`, [req.params.id])
    const txIds = txs.map(t => t.id)
    let amounts = []
    if (txIds.length > 0) {
      const { rows } = await pool.query(
        `SELECT ta.*, cu.symbol, cu.name AS currency_name, cu.color, cu.rate_to_base, cu.image_url
         FROM transaction_amounts ta JOIN currencies cu ON cu.id=ta.currency_id
         WHERE ta.transaction_id=ANY($1)`, [txIds])
      amounts = rows
    }
    ok(res, txs.map(t => ({ ...t, amounts: amounts.filter(a => a.transaction_id===t.id) })))
  } catch(e) { err(res, e.message) }
})

router.post('/campaigns/:id/transactions', async (req, res) => {
  const { session, description, category_id, type, amounts } = req.body
  if (!session || !description || !type || !amounts?.length)
    return err(res, 'session, description, type, amounts erforderlich', 400)
  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const { rows:[tx] } = await client.query(
      `INSERT INTO transactions(campaign_id,session,description,category_id,type) VALUES($1,$2,$3,$4,$5) RETURNING *`,
      [req.params.id, session, description, category_id||null, type])
    for (const a of amounts) {
      if (Number(a.amount)===0) continue
      await client.query(
        `INSERT INTO transaction_amounts(transaction_id,currency_id,amount) VALUES($1,$2,$3)`,
        [tx.id, a.currency_id, a.amount])
    }
    await client.query('COMMIT')
    const { rows: amts } = await client.query(
      `SELECT ta.*, cu.symbol, cu.name AS currency_name, cu.color, cu.rate_to_base, cu.image_url
       FROM transaction_amounts ta JOIN currencies cu ON cu.id=ta.currency_id
       WHERE ta.transaction_id=$1`, [tx.id])
    ok(res, { ...tx, amounts: amts })
  } catch(e) { await client.query('ROLLBACK'); err(res, e.message) }
  finally { client.release() }
})

router.delete('/transactions/:id', async (req, res) => {
  try { await pool.query('DELETE FROM transactions WHERE id=$1', [req.params.id]); ok(res, { deleted:true }) }
  catch(e) { err(res, e.message) }
})

module.exports = router
