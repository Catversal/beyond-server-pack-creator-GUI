#!/usr/bin/env node
/**
 * D&D Schatzkammer – Static File Server
 * Serves the built React app from the ./dist directory.
 * Usage: node serve.js [port]
 */

const http  = require('http')
const fs    = require('fs')
const path  = require('path')
const PORT  = parseInt(process.env.PORT || process.argv[2] || '3000', 10)
const DIST  = path.join(__dirname, 'dist')

const MIME  = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript',
  '.css':  'text/css',
  '.svg':  'image/svg+xml',
  '.png':  'image/png',
  '.ico':  'image/x-icon',
  '.json': 'application/json',
  '.woff2':'font/woff2',
  '.woff': 'font/woff',
  '.ttf':  'font/ttf',
}

const server = http.createServer((req, res) => {
  // Strip query string
  let urlPath = req.url.split('?')[0]

  // Resolve to file in dist/
  let filePath = path.join(DIST, urlPath)

  // Security: prevent path traversal
  if (!filePath.startsWith(DIST)) {
    res.writeHead(403); res.end('Forbidden'); return
  }

  // If directory → try index.html inside it
  if (fs.existsSync(filePath) && fs.statSync(filePath).isDirectory()) {
    filePath = path.join(filePath, 'index.html')
  }

  // If file doesn't exist → SPA fallback to index.html
  if (!fs.existsSync(filePath)) {
    filePath = path.join(DIST, 'index.html')
  }

  const ext  = path.extname(filePath).toLowerCase()
  const mime = MIME[ext] || 'application/octet-stream'

  // Cache static assets (JS/CSS have hashed filenames from Vite)
  const isHashed = /\.[a-f0-9]{8,}\.(js|css)$/.test(filePath)
  if (isHashed) {
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable')
  } else {
    res.setHeader('Cache-Control', 'no-cache')
  }

  res.setHeader('Content-Type', mime)

  const stream = fs.createReadStream(filePath)
  stream.on('error', () => { res.writeHead(500); res.end('Server Error') })
  res.writeHead(200)
  stream.pipe(res)
})

server.listen(PORT, '0.0.0.0', () => {
  console.log(`✅  D&D Schatzkammer läuft auf http://0.0.0.0:${PORT}`)
  console.log(`   Im Heimnetz erreichbar unter http://<SERVER-IP>:${PORT}`)
  console.log(`   Stoppen mit: Ctrl+C`)
})

process.on('SIGTERM', () => { server.close(() => process.exit(0)) })
