export const DND_PRESET = {
  name: 'D&D Standard',
  currencies: [
    { name:'Platin',   symbol:'pp', color:'A8C5E0', rate_to_base:1000, sort_order:4 },
    { name:'Gold',     symbol:'gp', color:'C9A84C', rate_to_base:100,  sort_order:3 },
    { name:'Elektrum', symbol:'ep', color:'8FBC8F', rate_to_base:50,   sort_order:2 },
    { name:'Silber',   symbol:'sp', color:'B8C4D0', rate_to_base:10,   sort_order:1 },
    { name:'Kupfer',   symbol:'cp', color:'C87841', rate_to_base:1,    sort_order:0 },
  ],
  defaultCategories: [
    { name:'Quest-Belohnung',   type:'income'  },
    { name:'Schatzfund',        type:'income'  },
    { name:'Verkauf',           type:'income'  },
    { name:'Sonstiges',         type:'income'  },
    { name:'Ausrüstung',        type:'expense' },
    { name:'Tränke',            type:'expense' },
    { name:'Unterkunft / Rast', type:'expense' },
    { name:'Dienste',           type:'expense' },
    { name:'Essen & Trinken',   type:'expense' },
    { name:'Transport',         type:'expense' },
    { name:'Sonstiges',         type:'expense' },
  ]
}

// Gesamtwert in Basis-Einheiten
export function toBase(amounts, currencies) {
  return amounts.reduce((sum, a) => {
    const cur = currencies.find(c => c.id === a.currency_id)
    if (!cur) return sum
    return sum + Number(a.amount) * Number(cur.rate_to_base)
  }, 0)
}

// Basiswert → lesbarer String in höchster Währung
export function formatBase(base, currencies) {
  if (!currencies?.length) return '0'
  const sorted = [...currencies].sort((a,b) => b.rate_to_base - a.rate_to_base)
  const top = sorted[0]
  const val = base / Number(top.rate_to_base)
  return val.toLocaleString('de-DE', { minimumFractionDigits:2, maximumFractionDigits:2 }) + ' ' + top.symbol
}

/**
 * Wechselgeld-Algorithmus (greedy, so wenig höhere Münzen wie nötig)
 * wallet: [{ id, balance, rate_to_base, symbol }] (sortiert höchste zuerst)
 * costBase: Kosten in Basis-Einheiten
 * Gibt zurück: { amounts: [{currency_id, amount}], changeBack: [{currency_id, amount}] }
 * oder null wenn nicht genug Geld
 */
export function makeChange(wallet, costBase) {
  // Sortiere: höchste zuerst
  const coins = [...wallet].sort((a,b) => Number(b.rate_to_base) - Number(a.rate_to_base))

  let remaining = Math.ceil(costBase) // in Basis-Einheiten
  const taken = {}  // currency_id → wie viel wird genommen

  for (const coin of coins) {
    if (remaining <= 0) break
    const rate    = Number(coin.rate_to_base)
    const have    = Number(coin.balance)
    const needed  = Math.ceil(remaining / rate)
    const use     = Math.min(needed, have)
    if (use <= 0) continue
    taken[coin.id] = use
    remaining -= use * rate
  }

  if (remaining > 0) return null  // Nicht genug Geld

  // Wechselgeld zurück (overshoot)
  const overshoot = -remaining  // in Basis-Einheiten
  const changeBack = {}
  if (overshoot > 0) {
    // Gib kleinstmögliche Münzen zurück
    let leftover = overshoot
    const coinsAsc = [...coins].reverse()
    for (const coin of coinsAsc) {
      const rate  = Number(coin.rate_to_base)
      const count = Math.floor(leftover / rate)
      if (count > 0) {
        changeBack[coin.id] = count
        leftover -= count * rate
      }
    }
  }

  return {
    amounts:    Object.entries(taken).map(([id,amount])     => ({ currency_id:parseInt(id), amount })),
    changeBack: Object.entries(changeBack).map(([id,amount]) => ({ currency_id:parseInt(id), amount })),
  }
}
