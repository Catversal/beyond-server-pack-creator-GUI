import { useState } from 'react'
import { X, Plus, Trash2 } from 'lucide-react'
import { DND_PRESET } from './currency'

const EMPTY_CUR = { name:'', symbol:'', color:'C9A84C', rate_to_base:'', sort_order:'' }

export default function NewCampaignModal({ onClose, onCreate }) {
  const [name,   setName]   = useState('')
  const [desc,   setDesc]   = useState('')
  const [mode,   setMode]   = useState('dnd')   // 'dnd' | 'custom'
  const [csName, setCsName] = useState('Eigenes System')
  const [curs,   setCurs]   = useState([{ ...EMPTY_CUR }])
  const [busy,   setBusy]   = useState(false)
  const [err,    setErr]    = useState(null)

  function addCur()     { setCurs(c => [...c, { ...EMPTY_CUR }]) }
  function removeCur(i) { setCurs(c => c.filter((_,j) => j !== i)) }
  function setCur(i, f, v) { setCurs(c => c.map((x,j) => j===i ? { ...x, [f]:v } : x)) }

  async function submit() {
    if (!name.trim()) return setErr('Kampagnenname fehlt')
    setBusy(true); setErr(null)
    try {
      const currencySystem = mode === 'dnd'
        ? DND_PRESET
        : {
            name: csName,
            currencies: curs.map((c,i) => ({
              name:         c.name,
              symbol:       c.symbol,
              color:        c.color.replace('#',''),
              rate_to_base: Number(c.rate_to_base) || 1,
              sort_order:   Number(c.sort_order ?? (curs.length - i)),
            })),
            defaultCategories: []
          }
      await onCreate({ name: name.trim(), description: desc.trim() || null, currencySystem })
    } catch(e) { setErr(e.message) }
    finally    { setBusy(false) }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-hdr">
          <h2>Neue Kampagne</h2>
          <button className="btn-icon" onClick={onClose}><X size={18}/></button>
        </div>

        <div className="modal-body">
          {err && <div className="modal-err">{err}</div>}

          <div className="field">
            <label>Kampagnenname *</label>
            <input value={name} onChange={e=>setName(e.target.value)} placeholder="z.B. Vergessene Reiche" autoFocus/>
          </div>

          <div className="field">
            <label>Beschreibung</label>
            <input value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Optional…"/>
          </div>

          {/* Währungssystem */}
          <div className="field">
            <label>Währungssystem</label>
            <div className="toggle">
              <button className={`tog-btn ${mode==='dnd'?'tog-active':''}`} onClick={()=>setMode('dnd')}>
                D&amp;D Standard
              </button>
              <button className={`tog-btn ${mode==='custom'?'tog-active':''}`} onClick={()=>setMode('custom')}>
                Eigenes System
              </button>
            </div>
          </div>

          {mode === 'dnd' && (
            <div className="preset-info">
              <div className="preset-row">
                {DND_PRESET.currencies.map(c => (
                  <span key={c.symbol} className="preset-coin" style={{ borderColor: `#${c.color}`, color:`#${c.color}` }}>
                    {c.symbol}
                  </span>
                ))}
              </div>
              <p className="preset-rates">
                1 pp = 10 gp &nbsp;·&nbsp; 1 gp = 10 sp &nbsp;·&nbsp; 1 sp = 10 cp
              </p>
              <p className="preset-rates" style={{marginTop:2}}>
                (Wechselkurs: 1 pp = 100 gp, 1 gp = 10 sp, 1 sp = 10 cp)
              </p>
            </div>
          )}

          {mode === 'custom' && (
            <div className="custom-curs">
              <div className="field">
                <label>Name des Systems</label>
                <input value={csName} onChange={e=>setCsName(e.target.value)} placeholder="z.B. Eberron"/>
              </div>

              <div className="cur-list">
                {curs.map((c, i) => (
                  <div key={i} className="cur-row">
                    <input className="cur-inp" placeholder="Name" value={c.name}
                      onChange={e=>setCur(i,'name',e.target.value)}/>
                    <input className="cur-inp cur-sym" placeholder="Kürzel" value={c.symbol}
                      onChange={e=>setCur(i,'symbol',e.target.value)}/>
                    <div className="cur-color-wrap">
                      <input type="color" className="cur-color" value={`#${c.color}`}
                        onChange={e=>setCur(i,'color',e.target.value.replace('#',''))}/>
                    </div>
                    <input className="cur-inp cur-rate" placeholder="Kurs (cp)" type="number" min="1"
                      value={c.rate_to_base} onChange={e=>setCur(i,'rate_to_base',e.target.value)}
                      title="Wert in Basis-Einheiten (kleinste Währung = 1)"/>
                    <button className="btn-icon btn-icon-sm" onClick={()=>removeCur(i)} disabled={curs.length<=1}>
                      <Trash2 size={13}/>
                    </button>
                  </div>
                ))}
              </div>
              <button className="btn-add-cur" onClick={addCur}><Plus size={13}/> Währung</button>
              <p className="cur-hint">Kurs = Wert in Basis-Einheiten (kleinste Währung = 1)</p>
            </div>
          )}
        </div>

        <div className="modal-footer">
          <button className="btn-ghost" onClick={onClose}>Abbrechen</button>
          <button className="btn-submit" onClick={submit} disabled={busy}>
            {busy ? 'Erstelle…' : 'Kampagne erstellen'}
          </button>
        </div>
      </div>
    </div>
  )
}
