export const DND_PRESET = {
  name: 'D&D Standard',
  currencies: [
    { name: 'Platin',  symbol: 'pp', color: 'A8C5E0', rate_to_base: 1000, sort_order: 4 },
    { name: 'Gold',    symbol: 'gp', color: 'C9A84C', rate_to_base: 100,  sort_order: 3 },
    { name: 'Elektrum',symbol: 'ep', color: '8FBC8F', rate_to_base: 50,   sort_order: 2 },
    { name: 'Silber',  symbol: 'sp', color: 'B8C4D0', rate_to_base: 10,   sort_order: 1 },
    { name: 'Kupfer',  symbol: 'cp', color: 'C87841', rate_to_base: 1,    sort_order: 0 },
  ],
  defaultCategories: [
    { name: 'Quest-Belohnung',   type: 'income'  },
    { name: 'Schatzfund',        type: 'income'  },
    { name: 'Verkauf',           type: 'income'  },
    { name: 'Sonstiges',         type: 'income'  },
    { name: 'Ausrüstung',        type: 'expense' },
    { name: 'Tränke',            type: 'expense' },
    { name: 'Unterkunft / Rast', type: 'expense' },
    { name: 'Dienste',           type: 'expense' },
    { name: 'Essen & Trinken',   type: 'expense' },
    { name: 'Transport',         type: 'expense' },
    { name: 'Sonstiges',         type: 'expense' },
  ]
}

// Umrechnung: alle Beträge in Basis-Einheiten (cp)
export function toBase(amounts, currencies) {
  return amounts.reduce((sum, a) => {
    const cur = currencies.find(c => c.id === a.currency_id)
    if (!cur) return sum
    return sum + Number(a.amount) * Number(cur.rate_to_base)
  }, 0)
}

// Basis-Einheiten → lesbarer String in der höchsten Währung
export function formatBase(base, currencies) {
  if (!currencies?.length) return '0'
  const sorted = [...currencies].sort((a,b) => b.rate_to_base - a.rate_to_base)
  const top = sorted[0]
  const val = base / Number(top.rate_to_base)
  return val.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + top.symbol
}
