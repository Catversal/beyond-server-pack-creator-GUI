#!/usr/bin/env bash
# ============================================================
#  D&D Schatzkammer v2 – Installations-Script
#  Debian 12 / Ubuntu 22.04+  |  als root ausführen
# ============================================================
set -e

APP_DIR="/opt/dnd-treasury"
APP_USER="dndapp"
DB_NAME="dnd_treasury"
DB_USER="dndapp"
DB_PASS="${DB_PASSWORD:-$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c20)}"
PORT="${PORT:-3000}"
SERVICE="dnd-treasury"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

[[ $EUID -ne 0 ]] && error "Bitte als root oder mit sudo ausführen."

info "=== D&D Schatzkammer v2 Setup ==="

# ── Node.js ─────────────────────────────────────────────────
if ! command -v node &>/dev/null; then
  info "Node.js 20 wird installiert..."
  apt-get update -qq
  apt-get install -y curl ca-certificates
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
else
  info "Node.js: $(node -v)"
fi

# ── PostgreSQL ───────────────────────────────────────────────
if ! command -v psql &>/dev/null; then
  info "PostgreSQL wird installiert..."
  apt-get update -qq
  apt-get install -y postgresql postgresql-contrib
fi

systemctl enable postgresql
systemctl start postgresql

# Datenbank + User anlegen
info "Datenbank wird eingerichtet..."
su -c "psql -tc \"SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'\" | grep -q 1 || \
  psql -c \"CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';\"" postgres

su -c "psql -tc \"SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'\" | grep -q 1 || \
  psql -c \"CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};\"" postgres

# ── App-Verzeichnis ──────────────────────────────────────────
info "App wird nach ${APP_DIR} kopiert..."
mkdir -p "${APP_DIR}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cp -r "${SCRIPT_DIR}/server"         "${APP_DIR}/"
cp -r "${SCRIPT_DIR}/client/dist"    "${APP_DIR}/client-dist"
# Server erwartet client/dist relativ zu sich selbst
mkdir -p "${APP_DIR}/server/../client"
ln -sfn "${APP_DIR}/client-dist"     "${APP_DIR}/client/dist" 2>/dev/null || true

# .env schreiben
cat > "${APP_DIR}/server/.env" << ENVEOF
PORT=${PORT}
DB_HOST=localhost
DB_PORT=5432
DB_NAME=${DB_NAME}
DB_USER=${DB_USER}
DB_PASSWORD=${DB_PASS}
ENVEOF

# ── dotenv laden im Server ───────────────────────────────────
# Einfach: dotenv installieren damit .env geladen wird
cd "${APP_DIR}/server"
npm install --omit=dev 2>/dev/null || npm install

# dotenv hinzufügen falls nicht da
npm install dotenv 2>/dev/null || true

# Prepend dotenv/config to index.js if not present
if ! grep -q "dotenv" "${APP_DIR}/server/index.js"; then
  sed -i "1s/^/require('dotenv').config();\n/" "${APP_DIR}/server/index.js"
fi

# ── System-User ──────────────────────────────────────────────
if ! id "${APP_USER}" &>/dev/null; then
  useradd --system --no-create-home --shell /usr/sbin/nologin "${APP_USER}"
fi
chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}"

# ── systemd Service ──────────────────────────────────────────
info "systemd Service wird erstellt..."
cat > "/etc/systemd/system/${SERVICE}.service" << EOF
[Unit]
Description=D&D Schatzkammer v2
After=network.target postgresql.service
Requires=postgresql.service

[Service]
Type=simple
User=${APP_USER}
WorkingDirectory=${APP_DIR}/server
ExecStart=$(which node) ${APP_DIR}/server/index.js
EnvironmentFile=${APP_DIR}/server/.env
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${SERVICE}
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "${SERVICE}"
systemctl restart "${SERVICE}"

sleep 2
if systemctl is-active --quiet "${SERVICE}"; then
  SERVER_IP=$(hostname -I | awk '{print $1}')
  echo ""
  echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}║   ✅  Installation erfolgreich!                  ║${NC}"
  echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "  🌐  App:      ${GREEN}http://${SERVER_IP}:${PORT}${NC}"
  echo -e "  🗄️  DB-Name:  ${YELLOW}${DB_NAME}${NC}"
  echo -e "  🔑  DB-Pass:  ${YELLOW}${DB_PASS}${NC}  ← in ${APP_DIR}/server/.env gespeichert"
  echo ""
  echo -e "  Logs:    ${YELLOW}journalctl -u ${SERVICE} -f${NC}"
  echo -e "  Status:  ${YELLOW}systemctl status ${SERVICE}${NC}"
  echo ""
else
  error "Service nicht gestartet – prüfe: journalctl -u ${SERVICE} -xe"
fi
