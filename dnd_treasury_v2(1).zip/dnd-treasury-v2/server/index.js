const express = require('express')
const cors    = require('cors')
const path    = require('path')
const { initDB } = require('./db')
const routes  = require('./routes')

const app  = express()
const PORT = parseInt(process.env.PORT || '3000')
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, '..', 'uploads')

app.use(cors())
app.use(express.json())

// Static uploads
app.use('/uploads', express.static(UPLOAD_DIR))

// API
app.use('/api', routes)

// React Frontend
const DIST = path.join(__dirname, '..', 'client', 'dist')
app.use(express.static(DIST))
app.get('*', (req, res) => res.sendFile(path.join(DIST, 'index.html')))

initDB().then(() => {
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`✅  D&D Schatzkammer läuft auf http://0.0.0.0:${PORT}`)
  })
}).catch(e => { console.error('❌  DB:', e.message); process.exit(1) })
